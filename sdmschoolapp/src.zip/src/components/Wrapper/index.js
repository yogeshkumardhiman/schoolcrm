import React from "react";
import { View } from "react-native";
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Header from "../Header";
import CustomStatusBar from "../CustomStatusBar";
import styles from "./styles";

const Wrapper = ({
  children,
  showHeader = false,
  headerProps = {},
  noTopInset = false,
  disableBottomInset = false,
  edges = ['left', 'right', 'bottom'],
  parentStyle,

  // ✅ StatusBar control
  statusBarColor = "transparent",
  statusBarStyle = "light-content",
  translucent = true,

}) => {

  const insets = useSafeAreaInsets();

  const containerStyle = {
    flex: 1,
    marginTop: !showHeader && !noTopInset ? insets.top : 0,
    paddingBottom: disableBottomInset ? 0 : insets.bottom,
  };

  // ✅ Prepare Header Props
  const resolvedHeaderProps = typeof headerProps === 'string' 
    ? { title: headerProps } 
    : headerProps;

  return (
    <SafeAreaView
      edges={edges}
      style={[
        styles.parent,
        { backgroundColor: statusBarColor === 'transparent' ? '#FFFFFF' : statusBarColor },
        parentStyle
      ]}
    >
      <CustomStatusBar 
        backgroundColor={statusBarColor}
        barStyle={statusBarStyle}
        translucent={translucent}
      />

      {/* ✅ PERSISTENT STICKY HEADER */}
      {showHeader && <Header {...resolvedHeaderProps} />}

      {/* ✅ CONTENT HUB */}
      <View style={containerStyle}>
        {children}
      </View>

    </SafeAreaView>
  );
};

export { Wrapper };