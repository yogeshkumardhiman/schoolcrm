import { View, Text, TouchableOpacity } from 'react-native';
import { BookOpen, CheckCircle2, Clock3 } from 'lucide-react-native';
import { COLORS, STRINGS, formatDate } from '../../../utils';
import { styles } from './styles';

const HomeworkItem = ({ subject, title, dueDate, status, onMarkComplete }) => {
    const isCompleted = status === 'COMPLETED';

    return (
        <View style={styles.card}>
            <View style={[styles.statusLine, { backgroundColor: isCompleted ? COLORS.success : COLORS.warning }]} />
            <View style={styles.content}>
                <View style={styles.header}>
                    <View style={styles.subjectBox}>
                        <BookOpen size={14} color={COLORS.primary} />
                        <Text style={styles.subjectName}>{subject}</Text>
                    </View>
                    <View style={[styles.badge, { backgroundColor: isCompleted ? '#DCFCE7' : '#FEF3C7' }]}>
                        <Text style={[styles.badgeText, { color: isCompleted ? COLORS.success : COLORS.warning }]}>
                            {isCompleted ? STRINGS.completed : STRINGS.pending}
                        </Text>
                    </View>
                </View>

                <Text style={styles.title}>{title}</Text>

                <View style={styles.footer}>
                    <Clock3 size={12} color={COLORS.gray} />
                    <Text style={styles.dateText}>{STRINGS.dueDate}: {formatDate(dueDate)}</Text>
                </View>
            </View>
            
            <View style={styles.actionContainer}>
                {isCompleted ? (
                    <View style={styles.checkIcon}>
                        <CheckCircle2 size={24} color={COLORS.success} />
                    </View>
                ) : (
                    onMarkComplete && (
                        <TouchableOpacity 
                            style={styles.markCompleteBtn}
                            onPress={onMarkComplete}
                            activeOpacity={0.7}
                        >
                            <CheckCircle2 size={24} color={COLORS.border} />
                        </TouchableOpacity>
                    )
                )}
            </View>
        </View>
    );
};

export default HomeworkItem;
