import { StyleSheet } from 'react-native';
import { COLORS, fontFamily } from '../../../utils';

export const styles = StyleSheet.create({
    card: {
        flexDirection: 'row',
        backgroundColor: COLORS.white,
        borderRadius: 20,
        marginBottom: 16,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: '#F1F5F9',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.03,
        shadowRadius: 10,
        elevation: 3,
    },
    statusLine: {
        width: 6,
        height: '100%',
    },
    content: {
        flex: 1,
        padding: 16,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    subjectBox: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    subjectName: {
        fontSize: 11,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.primary,
        marginLeft: 6,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    badge: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 8,
    },
    badgeText: {
        fontSize: 10,
        fontFamily: fontFamily.Poppins.Black,
    },
    title: {
        fontSize: 15,
        fontFamily: fontFamily.Poppins.ExtraBold,
        color: COLORS.secondary,
        marginVertical: 6,
        lineHeight: 20,
    },
    footer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 4,
    },
    dateText: {
        fontSize: 11,
        fontFamily: fontFamily.Poppins.SemiBold,
        color: COLORS.gray,
        marginLeft: 6,
    },
    checkIcon: {
        justifyContent: 'center',
    },
    actionContainer: {
        paddingRight: 16,
        justifyContent: 'center',
        alignItems: 'center',
    },
    markCompleteBtn: {
        width: 40,
        height: 40,
        borderRadius: 12,
        backgroundColor: '#F8FAFC',
        borderWidth: 1,
        borderColor: COLORS.border,
        alignItems: 'center',
        justifyContent: 'center',
    }
});
