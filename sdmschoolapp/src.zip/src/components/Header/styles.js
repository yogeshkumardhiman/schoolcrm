import { StyleSheet } from 'react-native';
import { COLORS, fontFamily } from '../../utils';

export default StyleSheet.create({
    gradientHeader: {
        paddingHorizontal: 20,
        paddingBottom: 25,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 15,
        elevation: 10,
        zIndex: 100,
    },
    topRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 30,

    },
    sideCol: {
        width: 44,
        alignItems: 'center',
        justifyContent: 'center',
    },
    titleCol: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 22,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
        letterSpacing: -0.5,
    },
    iconBtn: {
        width: 44,
        height: 44,
        backgroundColor: 'rgba(255,255,255,0.15)',
        borderRadius: 22,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
