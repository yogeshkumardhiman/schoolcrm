import React from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from "@react-navigation/native";
import { ChevronLeft, Menu } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import { COLORS } from '../../utils';
import styles from './styles';

const Header = ({
    title,
    showBack = false,
    showMenu = false,
    onMenuPress,
    rightComponent,
    children, // ✅ Slot for summary cards/metrics
    renderContent, // ✅ Slot for fully custom nodes (Dashboard)
    containerStyle,
    titleStyle,
    topstyle,
    noBottomRadius = false,
    paddingBottom = 25,
}) => {
    const navigation = useNavigation();
    const insets = useSafeAreaInsets();

    const renderHeaderContent = () => {
        if (renderContent) return renderContent();

        return (
            <View>
                <View style={[styles.topRow, topstyle]}>
                    <View style={styles.sideCol}>
                        {showBack && (
                            <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.goBack()}>
                                <ChevronLeft size={24} color={COLORS.white} />
                            </TouchableOpacity>
                        )}
                        {showMenu && (
                            <TouchableOpacity style={styles.iconBtn} onPress={onMenuPress}>
                                <Menu size={24} color={COLORS.white} />
                            </TouchableOpacity>
                        )}
                    </View>

                    <View style={styles.titleCol}>
                        <Text style={[styles.title, titleStyle]} numberOfLines={1}>
                            {title}
                        </Text>
                    </View>

                    <View style={styles.sideCol}>
                        {rightComponent ? rightComponent : <View style={{ width: 44 }} />}
                    </View>
                </View>
                {children}
            </View>
        );
    };

    return (
        <LinearGradient
            colors={COLORS.gradient}
            style={[
                styles.gradientHeader,
                {
                    paddingTop: insets.top + (renderContent ? 0 : 6),
                    paddingBottom: paddingBottom,
                    borderBottomLeftRadius: noBottomRadius ? 0 : 30,
                    borderBottomRightRadius: noBottomRadius ? 0 : 30,
                },
                containerStyle
            ]}
        >
            {renderHeaderContent()}
        </LinearGradient>
    );
};

export default Header;