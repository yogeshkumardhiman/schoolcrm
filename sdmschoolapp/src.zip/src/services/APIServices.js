import { API_END_POINTS, APIkit } from "../utils";

class APIService {
    // 🛡️ AUTHENTICATION
    login = (payload) => {
        return APIkit.post(API_END_POINTS.login, payload);
    };

    // 🎓 STUDENT PORTAL
    getStudentDashboard = (admissionNo) => {
        return APIkit.get(`${API_END_POINTS.studentDashboard}/${admissionNo}`);
    };

    getStudentAttendance = (studentId) => {
        return APIkit.get(`${API_END_POINTS.studentAttendance}/${studentId}`);
    };

    getStudentResults = (studentId) => {
        return APIkit.get(`${API_END_POINTS.studentResults}/${studentId}`);
    };

    getNotices = () => {
        return APIkit.get(API_END_POINTS.notices);
    };

    getEvents = () => {
        return APIkit.get(API_END_POINTS.events);
    };

    // 👨‍🏫 TEACHER HUB
    getClassStudents = (className, sectionName = '') => {
        const path = sectionName ? `${className}/${sectionName}` : className;
        return APIkit.get(`${API_END_POINTS.teacherStudents}/${path}`);
    };

    markAttendance = (payload) => {
        return APIkit.post(API_END_POINTS.markAttendance, payload);
    };

    postBulkResults = (payload) => {
        return APIkit.post(API_END_POINTS.bulkResults, payload);
    };

    broadcastNotice = (payload) => {
        return APIkit.post('admin/broadcast', payload);
    };
    
    postHomework = (payload) => {
        return APIkit.post('admin/homework', payload);
    };

    getHomework = (className, sectionName) => {
        return APIkit.get(`${API_END_POINTS.homework}?class=${className}&section=${sectionName}`);
    };

    getStudentHomeworkStatus = (studentId) => {
        return APIkit.get(`${API_END_POINTS.myHomeworkStatus}?studentId=${studentId}`);
    };

    updateHomeworkStatus = (payload) => {
        return APIkit.post(API_END_POINTS.homeworkStatus, payload);
    };

    // 🏫 INSTITUTIONAL DATA
    getStaffList = () => {
        return APIkit.get(API_END_POINTS.staff);
    };

    getSchoolInfo = () => {
        return APIkit.get(API_END_POINTS.schoolInfo);
    };
}

export { APIService };