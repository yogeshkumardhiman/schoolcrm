import { APIService } from "../services/APIServices";
import { showToast } from "../utils/helper";

// --- 👨‍🏫 TEACHER HUB THUNKS ---

// Fetch Class Scholar Registry
export const getClassRegistry = (className, sectionName, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getClassStudents(className, sectionName);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Class Registry Error:", err);
            callback(null);
        }
    };
};

// Commit Attendance for Class
export const commitAttendance = (payload, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().markAttendance(payload);
            if (response?.status === 200) {
                showToast({ type: 'success', message: 'Attendance committed successfully' });
                callback(response.data);
            }
        } catch (err) {
            showToast({ type: 'error', message: 'Failed to commit attendance' });
            callback(null);
        }
    };
};

// Upload Bulk Academic Marks
export const uploadBulkMarks = (payload, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().postBulkResults(payload);
            if (response?.status === 200) {
                showToast({ type: 'success', message: 'Marks uploaded successfully' });
                callback(response.data);
            }
        } catch (err) {
            showToast({ type: 'error', message: 'Failed to upload marks' });
            callback(null);
        }
    };
};

// Broadcast Institutional Notice
export const broadcastClassNotice = (payload, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().broadcastNotice(payload);
            if (response?.status === 200 || response?.status === 201) {
                showToast({ type: 'success', message: 'Notice broadcasted successfully' });
                callback(response.data);
            }
        } catch (err) {
            showToast({ type: 'error', message: 'Failed to broadcast notice' });
            callback(null);
        }
    };
};

// Deploy Homework Assignment
export const deployHomework = (payload, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().postHomework(payload);
            if (response?.status === 200 || response?.status === 201) {
                showToast({ type: 'success', message: 'Assignment deployed successfully' });
                callback(response.data);
            }
        } catch (err) {
            showToast({ type: 'error', message: 'Failed to deploy assignment' });
            callback(null);
        }
    };
};

export default {
    getClassRegistry,
    commitAttendance,
    uploadBulkMarks,
    broadcastClassNotice
};
