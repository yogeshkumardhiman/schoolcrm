import { APIService } from "../services/APIServices";


// --- 🎓 STUDENT THUNKS ---

// Fetch Student Dashboard Data
export const getDashboardData = (admissionNo, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getStudentDashboard(admissionNo);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Dashboard Fetch Error:", err);
            callback(null);
        }
    };
};

// Fetch Student Attendance
export const getAttendanceRecord = (studentId, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getStudentAttendance(studentId);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Attendance Fetch Error:", err);
            callback(null);
        }
    };
};

// Fetch Academic Results
export const getAcademicResults = (studentId, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getStudentResults(studentId);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Results Fetch Error:", err);
            callback(null);
        }
    };
};

// Fetch School Notices
export const getInstitutionalNotices = (callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getNotices();
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Notices Fetch Error:", err);
            callback(null);
        }
    };
};
// Fetch Class Homework
export const getHomeworkRecords = (className, sectionName, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getHomework(className, sectionName);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Homework Fetch Error:", err);
            callback(null);
        }
    };
};

// Fetch Homework Status for Student
export const getHomeworkStatus = (studentId, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().getStudentHomeworkStatus(studentId);
            if (response?.status === 200) {
                callback(response.data);
            }
        } catch (err) {
            console.error("Homework Status Fetch Error:", err);
            callback(null);
        }
    };
};

// Update Homework Status
export const updateHomeworkStatus = (payload, callback) => {
    return async dispatch => {
        try {
            const response = await new APIService().updateHomeworkStatus(payload);
            if (response?.status === 200) {
                callback(true);
            } else {
                callback(false);
            }
        } catch (err) {
            console.error("Homework Status Update Error:", err);
            callback(false);
        }
    };
};

export default {
    getDashboardData,
    getAttendanceRecord,
    getAcademicResults,
    getInstitutionalNotices,
    getHomeworkRecords,
    getHomeworkStatus,
    updateHomeworkStatus
};