import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import PublicRoutes from './publicRoutes';
import PrivateRoutes from './privateRoutes';

const AppNavigator = ({ showBoarding }) => {
    const { token, role } = useSelector(state => state.auth);
    console.log("role", role)

    return (
        <NavigationContainer>
            {!token ? (
                <PublicRoutes showBoarding={showBoarding} />
            ) : (
                <PrivateRoutes role={role} />
            )}
        </NavigationContainer>
    );
};

export default AppNavigator;


// import React from 'react';
// import { NavigationContainer } from '@react-navigation/native';
// import { useSelector } from 'react-redux';
// import PublicRoutes from './publicRoutes';
// import PrivateRoutes from './privateRoutes';

// const AppNavigator = ({ showBoarding }) => {
//     const { token } = useSelector(state => state.auth);
//     const role = 'Teacher'; // FORCED FOR TESTING
//     console.log("role", role)

//     return (
//         <NavigationContainer>
//             <PrivateRoutes role={role} />
//             {/* )} */}
//         </NavigationContainer>
//     );
// };

// export default AppNavigator;