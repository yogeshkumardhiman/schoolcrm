import React, { useEffect, useRef } from "react";
import { View, Pressable, Text, StyleSheet, Animated } from "react-native";
import { Home, Calendar, User, Bell, GraduationCap } from "lucide-react-native";
import { COLORS, fontFamily } from "../utils";

const TabBarItem = ({ route, index, state, navigation, label, IconComponent }) => {
    const isFocused = state.index === index;
    const scaleAnim = useRef(new Animated.Value(1)).current;
    const opacityAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.spring(scaleAnim, {
                toValue: isFocused ? 1.1 : 1,
                useNativeDriver: true,
                friction: 8,
            }),
            Animated.timing(opacityAnim, {
                toValue: isFocused ? 1 : 0,
                duration: 200,
                useNativeDriver: true,
            }),
        ]).start();
    }, [isFocused]);

    const handlePress = () => {
        const event = navigation.emit({
            type: "tabPress",
            target: route.key,
        });

        if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
        }
    };

    return (
        <Pressable
            onPress={handlePress}
            style={styles.tabItem}
        >
            <Animated.View style={{ transform: [{ scale: scaleAnim }], alignItems: 'center' }}>
                <IconComponent
                    size={22}
                    color={isFocused ? COLORS.primary : '#64748B'}
                    strokeWidth={isFocused ? 2.5 : 2}
                />
                <Text
                    style={[
                        styles.text,
                        {
                            color: isFocused ? COLORS.primary : '#64748B',
                            opacity: isFocused ? 1 : 0.7
                        },
                    ]}
                >
                    {label}
                </Text>
            </Animated.View>
            <Animated.View style={[styles.activeIndicator, { opacity: opacityAnim }]} />
        </Pressable>
    );
};

const TabBar = ({ state, navigation }) => {
    return (
        <View style={styles.outerContainer}>
            <View style={styles.mainContainer}>
                {state?.routes?.map((route, index) => {
                    let IconComponent = Home;
                    let label = "";

                    switch (route.name) {
                        case "HomeScreen":
                            IconComponent = Home;
                            label = "Home";
                            break;
                        case "ActivityScreen":
                            IconComponent = Calendar;
                            label = "Attendance";
                        break;
                        case "MarksScreen":
                            IconComponent = GraduationCap;
                            label = "Marks";
                            break;
                        case "NoticeScreen":
                            IconComponent = Bell;
                            label = "Notices";
                            break;
                        case "ProfileScreen":
                            IconComponent = User;
                            label = "Profile";
                            break;
                        default:
                            IconComponent = Home;
                            label = "Home";
                    }

                    return (
                        <TabBarItem
                            key={route.key}
                            route={route}
                            index={index}
                            state={state}
                            navigation={navigation}
                            label={label}
                            IconComponent={IconComponent}
                        />
                    );
                })}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    outerContainer: {
        position: 'absolute',
        bottom: 25,
        left: 15,
        right: 15,
        backgroundColor: COLORS.white,
        borderRadius: 24,
        shadowColor: '#6366F1',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.12,
        shadowRadius: 15,
        elevation: 10,
        borderWidth: 1,
        borderColor: 'rgba(99, 102, 241, 0.08)',
    },
    mainContainer: {
        flexDirection: 'row',
        height: 70,
        alignItems: 'center',
        paddingHorizontal: 5,
    },
    tabItem: {
        flex: 1,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        fontSize: 10,
        fontFamily: fontFamily.Poppins.Bold,
        marginTop: 4,
    },
    activeIndicator: {
        width: 12,
        height: 3,
        borderRadius: 2,
        backgroundColor: COLORS.primary,
        position: 'absolute',
        bottom: 10,
    }
});

export default TabBar;
