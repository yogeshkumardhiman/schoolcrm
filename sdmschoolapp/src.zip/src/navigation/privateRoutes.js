import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

// 🧭 SHARED
import TabBar from './TabBar';

// 🎓 STUDENT SCREENS
import StudentDashboard from '../screens/private/student/Dashboard';
import StudentAttendance from '../screens/private/student/Attendance';
import StudentExams from '../screens/private/student/Exams';
import StudentHomework from '../screens/private/student/Homework';
import StudentFees from '../screens/private/student/Fees';
import StudentNotice from '../screens/private/student/Notice';
import StudentNoticeDetail from '../screens/private/student/Notice/Detail';
import StudentEvents from '../screens/private/student/Events';
import HelpDesk from '../screens/private/student/HelpDesk';

// 🍎 TEACHER SCREENS
import TeacherDashboard from '../screens/private/teacher/Dashboard';
import AttendanceMarking from '../screens/private/teacher/Attendance';
import StudentRegistry from '../screens/private/teacher/Students';
import TestList from '../screens/private/teacher/Exams/TestList';
import AddMarks from '../screens/private/teacher/Exams/AddMarks';
import AddHomework from '../screens/private/teacher/Homework/AddHomework';
import AddNotice from '../screens/private/teacher/Notice/AddNotice';
import StudentQueries from '../screens/private/teacher/StudentQueries';
import Profile from '../screens/private/common/Profile';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// 🏠 PRIMARY TABS ROOT
const TabNav = ({ role }) => (
    <Tab.Navigator
        tabBar={props => <TabBar {...props} />}
        screenOptions={{
            headerShown: false,
        }}
    >
        <Tab.Screen 
            name="HomeScreen" 
            component={role === 'student' ? StudentDashboard : TeacherDashboard} 
        />
        <Tab.Screen 
            name="ActivityScreen" 
            component={role === 'student' ? StudentAttendance : AttendanceMarking} 
        />
        {role === 'student' && (
            <>
                <Tab.Screen name="MarksScreen" component={StudentExams} />
                <Tab.Screen name="NoticeScreen" component={StudentNotice} />
            </>
        )}
        <Tab.Screen name="ProfileScreen">
            {(props) => <Profile {...props} role={role} />}
        </Tab.Screen>
    </Tab.Navigator>
);

// 🚀 GLOBAL NAVIGATION HUB (Suggested by User)
const PrivateRoutes = ({ role }) => (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
        {/* Main Application Shell */}
        <Stack.Screen name="MainTabs">
            {(props) => <TabNav {...props} role={role} />}
        </Stack.Screen>

        {/* 🎓 GLOBAL STUDENT SUB-SCREENS */}
        <Stack.Screen name="StudentNoticeDetail" component={StudentNoticeDetail} />
        <Stack.Screen name="StudentEvents" component={StudentEvents} />
        <Stack.Screen name="StudentHomework" component={StudentHomework} />
        <Stack.Screen name="StudentFees" component={StudentFees} />
        <Stack.Screen name="HelpDesk" component={HelpDesk} />
        
        {/* 🍎 GLOBAL TEACHER SUB-SCREENS */}
        <Stack.Screen name="AttendanceMarking" component={AttendanceMarking} />
        <Stack.Screen name="StudentRegistry" component={StudentRegistry} />
        <Stack.Screen name="TestList" component={TestList} />
        <Stack.Screen name="AddMarks" component={AddMarks} />
        <Stack.Screen name="AddHomework" component={AddHomework} />
        <Stack.Screen name="AddNotice" component={AddNotice} />
        <Stack.Screen name="StudentQueries" component={StudentQueries} />

        {/* 👤 SHARED SCREENS */}
        <Stack.Screen name="Profile" component={Profile} />
    </Stack.Navigator>
);

export default PrivateRoutes;
