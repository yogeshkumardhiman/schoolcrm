import React, { useState, useEffect } from 'react';
import { StatusBar } from 'react-native';
import { Provider } from 'react-redux';
import Toast from 'react-native-toast-message';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import store from './store';
import AppNavigator from './navigation/routes';
import { CACHE, CACHE_PARAMS } from './utils';
import { loginSuccess } from './slices/authSlice';

import SplashScreen from './screens/public/SplashScreen';

const App = () => {
  const [showBoarding, setShowBoarding] = useState(true);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        // --- 🏄 CHECK ONBOARDING STATUS ---
        const onboardingValue = await CACHE.get(CACHE_PARAMS.onboarding);
        if (onboardingValue !== null) setShowBoarding(false);

        // --- 🔐 RESTORE INSTITUTIONAL SESSION ---
        const token = await CACHE.get(CACHE_PARAMS.accessToken);
        const user = await CACHE.get(CACHE_PARAMS.userData);
        const role = await CACHE.get(CACHE_PARAMS.userType);

        if (token && user) {
          store.dispatch(loginSuccess({ token, user, role }));
        }
      } catch (e) {
        console.log("⚓ Initialization Protocol Failure:", e);
      } finally {
        // Enforce Splash visibility for branding even if init is fast
        setTimeout(() => {
          setIsInitializing(false);
        }, 3000);
      }
    };
    initializeApp();
  }, []);

  return (
    <SafeAreaProvider>
      <Provider store={store}>
        <StatusBar barStyle="dark-content" />
        {isInitializing ? (
          <SplashScreen />
        ) : (
          <AppNavigator showBoarding={showBoarding} />
        )}
        <Toast />
      </Provider>
    </SafeAreaProvider>
  );
};

export default App;




