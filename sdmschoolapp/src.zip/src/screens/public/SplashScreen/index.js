import React, { useEffect } from 'react';
import { View, Text, Animated } from 'react-native';
import { GraduationCap } from 'lucide-react-native';
import { STRINGS, COLORS } from '../../../utils'
import { styles } from './styles';

const SplashScreen = ({ navigation }) => {
    const fadeAnim = new Animated.Value(0);
    const scaleAnim = new Animated.Value(0.8);

    useEffect(() => {
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: true,
            }),
            Animated.spring(scaleAnim, {
                toValue: 1,
                friction: 4,
                useNativeDriver: true,
            }),
        ]).start();

        const timer = setTimeout(() => {
            if (navigation) {
                navigation.replace('AppIntroSlider');
            }
        }, 2500);

        return () => clearTimeout(timer);
    }, [navigation]);

    return (
        <View style={styles.container}>
            <Animated.View style={[styles.content, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
                <View style={styles.iconCircle}>
                    <GraduationCap size={80} color={COLORS.primary} strokeWidth={1.5} />
                </View>
                <Text style={styles.appName}>{STRINGS.appName}</Text>
                <Text style={styles.tagline}>{STRINGS.tagline}</Text>
            </Animated.View>

            <View style={styles.footer}>
                <Text style={styles.version}>{STRINGS.version}</Text>
            </View>
        </View>
    );
};

export default SplashScreen;