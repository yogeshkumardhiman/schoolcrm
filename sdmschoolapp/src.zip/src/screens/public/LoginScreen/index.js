import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, Alert,
  ActivityIndicator, SafeAreaView, ScrollView,
  KeyboardAvoidingView, Platform
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { Eye, EyeOff, GraduationCap, Briefcase } from 'lucide-react-native';
import { APIkit, API_END_POINTS, CACHE, CACHE_PARAMS, STRINGS } from '../../../utils';
import styles from './styles';
import { loginStart, loginSuccess, loginFailure } from '../../../slices/authSlice';

import { CustomInput } from '../../../components/CustomInput';
import { CustomButton } from '../../../components/CustomButton';
import { StatusModal } from '../../../components/common/StatusModal';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student'); // 'student' or 'teacher'
  const [showPassword, setShowPassword] = useState(false);
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.auth);
  const [statusModal, setStatusModal] = useState({ visible: false, type: 'error', title: '', message: '' });

  const handleLogin = async () => {
    if (!email || !password) {
      setStatusModal({
        visible: true,
        type: 'error',
        title: 'CREDENTIAL ERROR',
        message: 'Please input your authorized institutional credentials.'
      });
      return;
    }

    dispatch(loginStart());

    try {
      const response = await APIkit.post(API_END_POINTS.login, {
        loginId: email,
        password: password,
        role: role
      });

      if (response.data && response.data.token) {
        try {
          await CACHE.set(CACHE_PARAMS.accessToken, response.data.token);
          await CACHE.set(CACHE_PARAMS.userData, response.data.user);
          await CACHE.set(CACHE_PARAMS.userType, response.data.role);
        } catch (e) {
          console.log("⚓ Session Persistence Registry Error", e);
        }

        dispatch(loginSuccess({
          token: response.data.token,
          user: response.data.user,
          role: response.data.role
        }));
      } else {
        throw new Error('Malformed Response Hub');
      }
    } catch (err) {
      console.log("💥 AUTH HUB FAILURE:", err);
      const serverError = err.response?.data?.error;
      const status = err.response?.status;
      
      let finalError = 'Institutional Connectivity Breach. Please verify your network entry point.';
      
      if (serverError) {
        finalError = serverError;
      } else if (status === 401) {
        finalError = 'Access Denied: Invalid institutional credentials provided.';
      } else if (err.message === 'Network Error') {
        finalError = 'Server Unreachable: Verify institutional IP/Port synchronization.';
      }

      dispatch(loginFailure(finalError));
      setStatusModal({
        visible: true,
        type: 'error',
        title: 'AUTHENTICATION DENIED',
        message: finalError
      });
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.logoCircle}>
              <Text style={styles.logoChar}>{STRINGS.logoChar}</Text>
            </View>
            <Text style={styles.title}>{STRINGS.appName}</Text>
            <Text style={styles.subtitle}>{STRINGS.institutionalHub}</Text>
          </View>

          <View style={styles.roleSelector}>
            <TouchableOpacity
              style={[styles.roleOption, role === 'student' && styles.activeRoleOption]}
              onPress={() => setRole('student')}
            >
              <GraduationCap size={20} color={role === 'student' ? '#fff' : '#666'} />
              <Text style={[styles.roleOptionText, role === 'student' && styles.activeRoleOptionText]}>{STRINGS.student}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.roleOption, role === 'teacher' && styles.activeRoleOption]}
              onPress={() => setRole('teacher')}
            >
              <Briefcase size={20} color={role === 'teacher' ? '#fff' : '#666'} />
              <Text style={[styles.roleOptionText, role === 'teacher' && styles.activeRoleOptionText]}>{STRINGS.teacher}</Text>
            </TouchableOpacity>
          </View>

          <View style={{ marginTop: 20 }}>
            <CustomInput 
              label={role === 'student' ? STRINGS.admissionId : STRINGS.officialEmail}
              placeholder={role === 'student' ? STRINGS.enterAdmission : STRINGS.enterEmail}
              value={email}
              onChangeText={setEmail}
              keyboardType={role === 'student' ? "numeric" : "email-address"}
            />

            <CustomInput 
              label={role === 'student' ? STRINGS.dobLabel : STRINGS.accessPassword}
              placeholder={STRINGS.password}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              rightIcon={showPassword ? Eye : EyeOff}
              onRightIconPress={() => setShowPassword(!showPassword)}
            />
          </View>

          <CustomButton 
            title={STRINGS.authenticate}
            onPress={handleLogin}
            loading={loading}
            variant="commit"
            style={{ marginTop: 20 }}
          />

          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={styles.forgotPasswordText}>{STRINGS.recoveryProtocol}</Text>
          </TouchableOpacity>

          <View style={styles.footer}>
            <Text style={styles.footerText}>{STRINGS.footerCredit}</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <StatusModal
        visible={statusModal.visible}
        type={statusModal.type}
        title={statusModal.title}
        message={statusModal.message}
        onClose={() => setStatusModal({ ...statusModal, visible: false })}
      />
    </SafeAreaView>
  );
};

export default LoginScreen;
