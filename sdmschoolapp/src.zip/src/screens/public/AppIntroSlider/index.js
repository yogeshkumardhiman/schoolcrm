import React, { useState, useRef } from 'react';
import { View, Text, FlatList, TouchableOpacity, SafeAreaView } from 'react-native';
import { GraduationCap, BookOpen, Bell, ArrowRight } from 'lucide-react-native';

import { styles } from './styles';
import { COLORS, STRINGS, CACHE, CACHE_PARAMS } from '../../../utils';

const SLIDES = [
    {
        id: '1',
        title: STRINGS.introTitle1,
        description: STRINGS.introDesc1,
        icon: GraduationCap,
        bgColor: COLORS.primary,
    },
    {
        id: '2',
        title: STRINGS.introTitle2,
        description: STRINGS.introDesc2,
        icon: BookOpen,
        bgColor: COLORS.secondary,
    },
    {
        id: '3',
        title: STRINGS.introTitle3,
        description: STRINGS.introDesc3,
        icon: Bell,
        bgColor: COLORS.accent,
    },
];

const AppIntroSlider = ({ navigation, onFinish }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const flatListRef = useRef(null);

    const onViewableItemsChanged = useRef(({ viewableItems }) => {
        if (viewableItems.length > 0) {
            setCurrentIndex(viewableItems[0].index);
        }
    }).current;

    const handleNext = async () => {
        if (currentIndex < SLIDES.length - 1) {
            flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
        } else {
            // --- 🏁 TERMINATE ONBOARDING SEQUENCE ---
            try {
                await CACHE.set(CACHE_PARAMS.onboarding, true);
            } catch (e) {
                console.log("⚓ Onboarding Persistence Failure", e);
            }

            if (onFinish) {
                onFinish();
            } else {
                navigation.replace('LoginScreen');
            }
        }
    };

    const renderItem = ({ item }) => {
        const IconComponent = item.icon;
        return (
            <View style={[styles.slide, { backgroundColor: item.bgColor }]}>
                <SafeAreaView style={styles.content}>
                    <View style={styles.iconContainer}>
                        <IconComponent size={120} color={COLORS.white} strokeWidth={1} />
                    </View>
                    <View style={styles.textContainer}>
                        <Text style={styles.title}>{item.title}</Text>
                        <Text style={styles.description}>{item.description}</Text>
                    </View>
                </SafeAreaView>
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <FlatList
                ref={flatListRef}
                data={SLIDES}
                renderItem={renderItem}
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onViewableItemsChanged={onViewableItemsChanged}
                viewabilityConfig={{ itemVisiblePercentThreshold: 50 }}
                keyExtractor={(item) => item.id}
            />

            <View style={styles.footer}>
                <View style={styles.pagination}>
                    {SLIDES.map((_, i) => (
                        <View
                            key={i}
                            style={[
                                styles.dot,
                                { width: i === currentIndex ? 24 : 8, backgroundColor: i === currentIndex ? COLORS.white : 'rgba(255,255,255,0.4)' },
                            ]}
                        />
                    ))}
                </View>

                <TouchableOpacity
                    style={[styles.nextButton, { backgroundColor: SLIDES[currentIndex].bgColor === COLORS.accent ? COLORS.primary : COLORS.white }]}
                    onPress={handleNext}
                >
                    <Text style={[styles.nextButtonText, { color: SLIDES[currentIndex].bgColor === COLORS.accent ? COLORS.white : SLIDES[currentIndex].bgColor }]}>
                        {currentIndex === SLIDES.length - 1 ? STRINGS.getStarted : STRINGS.next}
                    </Text>
                    <ArrowRight size={20} color={SLIDES[currentIndex].bgColor === COLORS.accent ? COLORS.white : SLIDES[currentIndex].bgColor} />
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default AppIntroSlider;




