import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, Modal, TextInput } from 'react-native';
import { User, Mail, Phone, Calendar, Droplets, MapPin, LogOut, Users, Edit3, Briefcase, Award, X } from 'lucide-react-native';
import { useSelector, useDispatch } from 'react-redux';
import { logout, updateAuth } from '../../../../slices/authSlice';
import { COLORS, getResolvedUrl, STRINGS, APIkit } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';

const Profile = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user, role } = useSelector(state => state.auth);
    const isTeacher = role?.toLowerCase() === 'teacher';
    
    const [isLogoutModalVisible, setLogoutModalVisible] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [loading, setLoading] = useState(false);
    
    const [formData, setFormData] = useState({
        about: user?.about || '',
        phone: user?.phone || '',
        address: user?.address || ''
    });

    const handleLogout = () => {
        setLogoutModalVisible(false);
        dispatch(logout());
    };

    const handleSave = async () => {
        setLoading(true);
        try {
            const res = await APIkit.put('teacher/profile/update', {
                email: user.email,
                ...formData
            });
            if (res.data.success) {
                dispatch(updateAuth({ user: { ...user, ...formData } }));
                setIsEditing(false);
            }
        } catch (e) {
            console.log("Profile Update Error:", e);
        } finally {
            setLoading(false);
        }
    };

    const InfoItem = ({ icon: Icon, label, value, color, field, multiline = false }) => (
        <View style={styles.infoItem}>
            <View style={[styles.iconBox, { backgroundColor: color + '15' }]}>
                <Icon size={20} color={color} />
            </View>
            <View style={styles.infoText}>
                <Text style={styles.infoLabel}>{label}</Text>
                {isEditing && field ? (
                    <TextInput
                        style={[styles.input, multiline && styles.textArea]}
                        value={formData[field]}
                        onChangeText={(txt) => setFormData({ ...formData, [field]: txt })}
                        placeholder={`Enter ${label}`}
                        multiline={multiline}
                    />
                ) : (
                    <Text style={styles.infoValue}>{value || 'N/A'}</Text>
                )}
            </View>
        </View>
    );

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: isTeacher ? STRINGS.facultyProfile : STRINGS.myProfile,
                paddingBottom: 40
            }}
        >
            <View style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                    
                    {isTeacher && (
                        <TouchableOpacity 
                            style={styles.editBtn} 
                            onPress={() => setIsEditing(!isEditing)}
                        >
                            {isEditing ? <X size={20} color={COLORS.primary} /> : <Edit3 size={20} color={COLORS.primary} />}
                        </TouchableOpacity>
                    )}

                    <View style={styles.profileCard}>
                        <View style={styles.avatarContainer}>
                            <View style={styles.avatarBorder}>
                                <Image
                                    source={{ uri: user?.image ? getResolvedUrl(user.image) : 'https://i.pravatar.cc/150?u=' + user?.name }}
                                    style={styles.avatar}
                                />
                            </View>
                            <Text style={styles.studentName}>{user?.name}</Text>
                            <Text style={styles.studentSub}>{isTeacher ? user?.designation : `${STRINGS.class} ${user?.class}`}</Text>
                            {!isTeacher && (
                                <>
                                    <Text style={styles.studentSub}>{STRINGS.rollNo}: {user?.rollNo}</Text>
                                    <Text style={styles.studentSub}>{STRINGS.session}: {user?.sessn || STRINGS.sessionYear}</Text>
                                </>
                            )}
                        </View>
                    </View>

                    {isEditing && (
                        <View style={styles.saveRow}>
                            <TouchableOpacity style={styles.cancelEditBtn} onPress={() => setIsEditing(false)}>
                                <Text style={[styles.btnText, { color: '#64748B' }]}>{STRINGS.cancelEdit}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
                                <Text style={styles.btnText}>{loading ? STRINGS.saving : STRINGS.saveChanges}</Text>
                            </TouchableOpacity>
                        </View>
                    )}

                    {isTeacher && (
                        <View style={styles.bioSection}>
                            <View style={styles.sectionHeader}>
                                <User size={20} color={COLORS.primary} />
                                <Text style={styles.sectionTitle}>{STRINGS.aboutMe}</Text>
                            </View>
                            {isEditing ? (
                                <TextInput
                                    style={[styles.input, styles.textArea]}
                                    value={formData.about}
                                    onChangeText={(txt) => setFormData({ ...formData, about: txt })}
                                    multiline
                                    placeholder={STRINGS.bioPlaceholderInput}
                                />
                            ) : (
                                <View style={styles.bioCard}>
                                    <Text style={styles.bioText}>{user?.about || STRINGS.bioPlaceholder}</Text>
                                </View>
                            )}
                        </View>
                    )}

                    <View style={styles.parentSection}>
                        <View style={styles.sectionHeader}>
                            {isTeacher ? <Briefcase size={20} color="#3B82F6" /> : <Users size={20} color="#3B82F6" />}
                            <Text style={styles.sectionTitle}>{isTeacher ? STRINGS.professionalOverview : STRINGS.studentDetails}</Text>
                        </View>
                        <View style={styles.parentCard}>
                            {isTeacher ? (
                                <>
                                    <InfoItem icon={Award} label={STRINGS.qualification} value={user?.qualification} color="#3B82F6" />
                                    <InfoItem icon={Calendar} label={STRINGS.subjects} value={user?.subject} color="#8B5CF6" />
                                    <InfoItem icon={Calendar} label={STRINGS.joiningDate} value={user?.joiningDate} color="#F59E0B" />
                                    <InfoItem icon={MapPin} label={STRINGS.workAddress} value={user?.address} color="#EF4444" field="address" multiline />
                                </>
                            ) : (
                                <>
                                    <InfoItem icon={User} label={STRINGS.studentId} value={user?.admissionNo} color="#3B82F6" />
                                    <InfoItem icon={Mail} label={STRINGS.email} value={user?.email} color="#8B5CF6" />
                                    <InfoItem icon={Calendar} label={STRINGS.dateOfBirth} value={user?.dob} color="#F59E0B" />
                                    <InfoItem icon={Droplets} label={STRINGS.bloodGroup} value={user?.bloodGroup} color="#EF4444" />
                                    <InfoItem icon={MapPin} label={STRINGS.address} value={user?.address} color="#3B82F6" />
                                </>
                            )}
                        </View>
                    </View>

                    <View style={styles.parentSection}>
                        <View style={styles.sectionHeader}>
                            <Phone size={20} color="#10B981" />
                            <Text style={styles.sectionTitle}>{isTeacher ? STRINGS.contactChannels : STRINGS.parentDetails}</Text>
                        </View>
                        <View style={styles.parentCard}>
                            {isTeacher ? (
                                <>
                                    <InfoItem icon={Phone} label={STRINGS.phoneNum} value={user?.phone} color="#10B981" field="phone" />
                                    <InfoItem icon={Mail} label={STRINGS.officialMail} value={user?.email} color="#8B5CF6" />
                                </>
                            ) : (
                                <>
                                    <InfoItem icon={User} label={STRINGS.parentName} value={user?.fatherName || "Rajesh kumar"} color="#3B82F6" />
                                    <InfoItem icon={Phone} label={STRINGS.phone} value={user?.phone} color="#10B981" />
                                    <InfoItem icon={Mail} label={STRINGS.email} value="rajesh.sharma@email.com" color="#8B5CF6" />
                                </>
                            )}
                        </View>
                    </View>

                    <TouchableOpacity style={styles.logoutBtn} onPress={() => setLogoutModalVisible(true)}>
                        <LogOut size={20} color={COLORS.danger} />
                        <Text style={styles.logoutText}>{STRINGS.logout}</Text>
                    </TouchableOpacity>

                    <View style={{ height: 120 }} />
                </ScrollView>

                {/* 🛡️ PREMIUM LOGOUT MODAL */}
                <Modal
                    visible={isLogoutModalVisible}
                    transparent={true}
                    animationType="fade"
                    onRequestClose={() => setLogoutModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <View style={styles.modalIconBox}>
                                <LogOut size={32} color={COLORS.danger} />
                            </View>
                            <Text style={styles.modalTitle}>{STRINGS.confirmLogout}</Text>
                            <Text style={styles.modalDesc}>{STRINGS.logoutDesc}</Text>

                            <View style={styles.modalActionRow}>
                                <TouchableOpacity
                                    style={styles.cancelBtn}
                                    onPress={() => setLogoutModalVisible(false)}
                                >
                                    <Text style={styles.cancelBtnText}>{STRINGS.cancel}</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    style={styles.confirmBtn}
                                    onPress={handleLogout}
                                >
                                    <Text style={styles.confirmBtnText}>{STRINGS.logout}</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>
        </Wrapper>
    );
};

export default Profile;
