import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Megaphone, ChevronLeft, Bell } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useDispatch } from 'react-redux';
import { COLORS, STRINGS, formatDate } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { getInstitutionalNotices } from '../../../../slices/student';

import Skeleton from '../../../../components/common/Skeleton';

const StudentNotice = ({ navigation }) => {
    const dispatch = useDispatch();
    const [notices, setNotices] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        setLoading(true);
        dispatch(getInstitutionalNotices((data) => {
            if (data) setNotices(data);
            setLoading(false);
        }));
    }, []);

    return (

        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: STRINGS.schoolNotice,   // ✅ string
                paddingBottom: 20,             // ✅ comma

                // ✅ अगर bottom radius हटाना है
                noBottomRadius: false,

                // ✅ custom styling
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}
        >

            <View style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                    <LinearGradient
                        colors={COLORS.gradient}
                        style={styles.headerGradient}
                    >
                        {/* <Text style={styles.headerTitle}>{STRINGS.schoolNotice}</Text> */}

                        <View style={styles.summaryCard}>
                            <View style={styles.announcementIcon}>
                                <Megaphone size={24} color={COLORS.primary} />
                            </View>
                            <Text style={styles.summaryText}>{STRINGS.adminSeal}</Text>
                        </View>
                    </LinearGradient>

                    <View style={styles.mainContent}>
                        {loading ? (
                            [1, 2, 3].map(i => (
                                <View key={i} style={[styles.noticeCard, { padding: 16 }]}>
                                    <Skeleton width="40%" height={12} borderRadius={4} style={{ marginBottom: 12 }} />
                                    <Skeleton width="80%" height={18} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="100%" height={14} borderRadius={4} style={{ marginBottom: 4 }} />
                                    <Skeleton width="100%" height={14} borderRadius={4} />
                                </View>
                            ))
                        ) : (
                            notices.map(item => (
                                <TouchableOpacity
                                    key={item.id}
                                    style={styles.noticeCard}
                                    onPress={() => navigation.navigate('StudentNoticeDetail', { notice: item })}
                                >
                                    <View style={styles.noticeHeader}>
                                        <View style={[styles.tagBadge, { backgroundColor: item.color + '20' }]}>
                                            <Text style={[styles.noticeTag, { color: item.color }]}>{item.tag}</Text>
                                        </View>
                                        <Text style={styles.noticeDate}>{formatDate(item.date)}</Text>
                                    </View>
                                    <Text style={styles.noticeTitle}>{item.title}</Text>
                                    <Text numberOfLines={2} style={styles.noticePreview}>{item.content}</Text>

                                    <View style={styles.readMoreRow}>
                                        <Text style={styles.readMoreText}>{STRINGS.seeAll}</Text>
                                        <Bell size={14} color={COLORS.primary} />
                                    </View>
                                </TouchableOpacity>
                            ))
                        )}
                    </View>
                    <View style={{ height: 120 }} />
                </ScrollView>
            </View>
        </Wrapper>
    );
};

export default StudentNotice;
