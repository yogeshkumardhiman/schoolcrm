import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { ChevronLeft, ChevronRight, Calendar as LucideCalendar, CheckCircle2, Clock, Info } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { Calendar } from 'react-native-calendars';
import { useDispatch, useSelector } from 'react-redux';
import { COLORS, STRINGS, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { getAttendanceRecord } from '../../../../slices/student';

const StudentAttendance = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);
    const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().split('T')[0]);
    const [attendanceData, setAttendanceData] = useState({});
    const [summary, setSummary] = useState({ present: 0, absent: 0, leave: 0, percentage: 0 });

    React.useEffect(() => {
        dispatch(getAttendanceRecord(user?.id || user?._id, (data) => {
            if (data) {
                const formatted = {};
                let p = 0, a = 0, l = 0;
                data.forEach(item => {
                    const status = item.status?.toUpperCase();
                    let color = '#10B981'; 
                    if (status === 'PRESENT') p++;
                    else if (status === 'ABSENT') { a++; color = '#EF4444'; }
                    else if (status === 'LEAVE') { l++; color = '#8B5CF6'; }

                    formatted[item.date] = {
                        marked: true,
                        customStyles: {
                            container: { backgroundColor: color, elevation: 2 },
                            text: { color: 'white', fontFamily: fontFamily.Poppins.Bold }
                        }
                    };
                });
                setAttendanceData(formatted);
                const total = data.length;
                const percentage = total > 0 ? ((p / total) * 100).toFixed(0) : 0;
                setSummary({ present: p, absent: a, leave: l, percentage });
            }
        }));
    }, [user?.id, user?._id]);


    const recentActivity = [
        { id: 1, date: 'April 9, 2026', status: 'Present', color: '#10B981', Icon: CheckCircle2, type: 'Normal' },
        { id: 2, date: 'April 15, 2026', status: 'Parent Meeting', color: '#3B82F6', Icon: Info, type: 'Event' },
        { id: 3, date: 'April 7, 2026', status: 'Leave Approved', color: '#8B5CF6', Icon: Clock, type: 'Normal' },
    ];

    return (

        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: STRINGS.attendance,   // ✅ string
                paddingBottom: 20,             // ✅ comma

                // ✅ अगर bottom radius हटाना है
                noBottomRadius: false,

                // ✅ custom styling
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}
        >

            <View style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                    <LinearGradient
                        colors={COLORS.gradient}
                        style={styles.headerGradient}
                    >
                        <View style={styles.summaryCard}>
                            <View style={styles.summaryLeft}>
                                <Text style={styles.summaryLabel}>{STRINGS.overallAttendance.toUpperCase()}</Text>
                                <Text style={styles.overallValue}>{summary.percentage}%</Text>
                                <View style={styles.statsRow}>
                                    <View style={[styles.miniStatBox, { backgroundColor: '#10B981' }]}>
                                        <Text style={styles.miniStatVal}>{summary.present}</Text>
                                        <Text style={styles.miniStatLab}>{STRINGS.present}</Text>
                                    </View>
                                    <View style={[styles.miniStatBox, { backgroundColor: '#EF4444' }]}>
                                        <Text style={styles.miniStatVal}>{summary.absent}</Text>
                                        <Text style={styles.miniStatLab}>{STRINGS.absent}</Text>
                                    </View>
                                    <View style={[styles.miniStatBox, { backgroundColor: '#8B5CF6' }]}>
                                        <Text style={styles.miniStatVal}>{summary.leave}</Text>
                                        <Text style={styles.miniStatLab}>{STRINGS.leave}</Text>
                                    </View>
                                </View>
                            </View>
                            <View style={styles.calIconBox}>
                                <LucideCalendar size={50} color={COLORS.primary} strokeWidth={1.5} />
                            </View>
                        </View>
                    </LinearGradient>

                    <View style={styles.mainContent}>
                        {/* 📅 INTERACTIVE CALENDAR */}
                        <View style={styles.calendarCard}>
                            <Calendar
                                markingType={'custom'}
                                markedDates={attendanceData}
                                renderArrow={(direction) => (
                                    <View style={styles.arrowBox}>
                                        {direction === 'left' ? (
                                            <ChevronLeft size={24} color={COLORS.primary} />
                                        ) : (
                                            <ChevronRight size={24} color={COLORS.primary} />
                                        )}
                                    </View>
                                )}
                                theme={{
                                    backgroundColor: '#ffffff',
                                    calendarBackground: '#ffffff',
                                    textSectionTitleColor: '#64748B',
                                    selectedDayBackgroundColor: COLORS.primary,
                                    selectedDayTextColor: '#ffffff',
                                    todayTextColor: COLORS.primary,
                                    dayTextColor: '#1F2937',
                                    textDisabledColor: '#CBD5E1',
                                    dotColor: COLORS.primary,
                                    selectedDotColor: '#ffffff',
                                    arrowColor: COLORS.primary,
                                    monthTextColor: COLORS.secondary,
                                    indicatorColor: COLORS.primary,
                                    textDayFontFamily: fontFamily.Poppins.ExtraBold,
                                    textMonthFontFamily: fontFamily.Poppins.Black,
                                    textDayHeaderFontFamily: fontFamily.Poppins.Bold,
                                    textDayFontSize: 14,
                                    textMonthFontSize: 18,
                                    textDayHeaderFontSize: 12,
                                }}
                                onMonthChange={(month) => setSelectedMonth(month.dateString)}
                            />

                            <View style={styles.legendRow}>
                                <View style={styles.legendItem}>
                                    <View style={[styles.legendDot, { backgroundColor: '#10B981' }]} />
                                    <Text style={styles.legendLabel}>{STRINGS.present}</Text>
                                </View>
                                <View style={styles.legendItem}>
                                    <View style={[styles.legendDot, { backgroundColor: '#EF4444' }]} />
                                    <Text style={styles.legendLabel}>{STRINGS.absent}</Text>
                                </View>
                                <View style={styles.legendItem}>
                                    <View style={[styles.legendDot, { backgroundColor: '#8B5CF6' }]} />
                                    <Text style={styles.legendLabel}>{STRINGS.leave}</Text>
                                </View>
                                <View style={styles.legendItem}>
                                    <View style={[styles.legendDot, { backgroundColor: '#3B82F6', borderRadius: 0 }]} />
                                    <Text style={styles.legendLabel}>EVENT</Text>
                                </View>
                            </View>
                        </View>

                        <Text style={styles.sectionTitle}>Activity & Events</Text>
                        {recentActivity.map(activity => (
                            <View key={activity.id} style={styles.activityCard}>
                                <View style={[styles.activityIcon, { backgroundColor: activity.color + '15' }]}>
                                    <activity.Icon size={22} color={activity.color} />
                                </View>
                                <View style={styles.activityInfo}>
                                    <Text style={[styles.activityStatus, { color: activity.color }]}>{activity.status}</Text>
                                    <Text style={styles.activityDate}>{activity.date}</Text>
                                </View>
                                {activity.type === 'Event' && (
                                    <View style={styles.eventBadge}>
                                        <Text style={styles.eventBadgeText}>EVENT</Text>
                                    </View>
                                )}
                            </View>
                        ))}
                    </View>
                    <View style={{ height: 120 }} />
                </ScrollView>
            </View>
        </Wrapper>
    );
};

export default StudentAttendance;
