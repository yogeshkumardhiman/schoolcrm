import { StyleSheet } from 'react-native';
import { fontFamily,COLORS } from '../../../../utils';


export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    headerGradient: {
        paddingTop: 60,
        paddingBottom: 40,
        paddingHorizontal: 24,
        borderBottomLeftRadius: 40,
        borderBottomRightRadius: 40,
    },
    backBtn: {
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 24,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
        marginBottom: 24,
    },
    summaryCard: {
        backgroundColor: 'rgba(255,255,255,0.15)',
        borderRadius: 24,
        padding: 24,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 20,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
    },
    statLabel: {
        fontSize: 9,
        fontFamily: fontFamily.Poppins.Bold,
        color: 'rgba(255,255,255,0.7)',
        marginTop: 2,
    },
    divider: {
        width: 1,
        height: 30,
        backgroundColor: 'rgba(255,255,255,0.2)',
    },
    // 📚 CONTENT
    mainContent: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 30,
    },
});
