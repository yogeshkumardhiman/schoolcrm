import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, Alert } from 'react-native';
import { ChevronLeft, BookOpen } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useDispatch, useSelector } from 'react-redux';
import { COLORS, STRINGS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import HomeworkItem from '../../../../components/Cards/HomeworkItem';
import { getHomeworkRecords, getHomeworkStatus, updateHomeworkStatus } from '../../../../slices/student';
import Skeleton from '../../../../components/common/Skeleton';
import { StatusModal } from '../../../../components/common/StatusModal';

const StudentHomework = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);
    const [homeworkList, setHomeworkList] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, title: '', message: '', type: 'info', onOk: null });

    const fetchHomework = async () => {
        setLoading(true);
        try {
            // 1. Fetch Class Homework
            dispatch(getHomeworkRecords(user?.class, user?.section || 'A', async (hwData) => {
                if (hwData) {
                    try {
                        // 2. Fetch Personal Statuses
                        dispatch(getHomeworkStatus(user?.id || user?._id, (statuses) => {
                            const hwStatuses = statuses || [];
                            
                            // 3. Merge Statuses
                            const merged = hwData.map(hw => {
                                const match = hwStatuses.find(s => String(s.homeworkId) === String(hw.id || hw._id));
                                return { ...hw, status: match ? match.status : 'PENDING' };
                            });
                            setHomeworkList(merged);
                            setLoading(false);
                            setRefreshing(false);
                        }));
                    } catch (e) {
                        setHomeworkList(hwData);
                        setLoading(false);
                        setRefreshing(false);
                    }
                } else {
                    setLoading(false);
                    setRefreshing(false);
                }
            }));
        } catch (error) {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        fetchHomework();
    }, []);

    const handleMarkComplete = (item) => {
        setStatusModal({
            visible: true,
            title: 'TASK COMPLETION',
            message: `Are you sure you have completed the ${item.subject} assignment: "${item.title}"?`,
            type: 'info',
            onOk: async () => {
                try {
                    setRefreshing(true);
                    dispatch(updateHomeworkStatus({
                        studentId: user?.id || user?._id,
                        homeworkId: item.id || item._id,
                        status: 'COMPLETED'
                    }, (success) => {
                        if (success) {
                            fetchHomework();
                        } else {
                            Alert.alert('Protocol Error', 'Failed to update task status.');
                            setRefreshing(false);
                        }
                    }));
                } catch (e) {
                    Alert.alert('Protocol Error', 'Failed to update task status.');
                    setRefreshing(false);
                }
            }
        });
    };

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);
        fetchHomework();
    }, []);

    const pendingCount = homeworkList.filter(i => i.status !== 'COMPLETED').length;
    const completedCount = homeworkList.length - pendingCount;

    return (
        <Wrapper noTopInset={true} translucent={true} statusBarColor="transparent" statusBarStyle="light-content">
            <ScrollView 
                showsVerticalScrollIndicator={false} 
                style={styles.container}
                refreshControl={
                    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[COLORS.primary]} />
                }
            >
                <LinearGradient
                    colors={COLORS.gradient}
                    style={styles.headerGradient}
                >
                    <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
                        <ChevronLeft size={28} color={COLORS.white} />
                    </TouchableOpacity>

                    <Text style={styles.headerTitle}>{STRINGS.homework}</Text>
                    
                    <View style={styles.summaryCard}>
                        <View style={styles.statItem}>
                            <Text style={styles.statValue}>{loading ? '--' : pendingCount}</Text>
                            <Text style={styles.statLabel}>{STRINGS.pending.toUpperCase()}</Text>
                        </View>
                        <View style={styles.divider} />
                        <View style={styles.statItem}>
                            <Text style={styles.statValue}>{loading ? '--' : completedCount}</Text>
                            <Text style={styles.statLabel}>{STRINGS.completed.toUpperCase()}</Text>
                        </View>
                    </View>
                </LinearGradient>

                <View style={styles.mainContent}>
                    {loading ? (
                        [1, 2, 3].map(i => (
                            <View key={i} style={[styles.skeletonCard, { marginBottom: 16, backgroundColor: '#F8FAFC', borderRadius: 20, padding: 16 }]}>
                                <Skeleton width="40%" height={12} borderRadius={4} style={{ marginBottom: 12 }} />
                                <Skeleton width="80%" height={18} borderRadius={4} style={{ marginBottom: 8 }} />
                                <Skeleton width="60%" height={12} borderRadius={4} />
                            </View>
                        ))
                    ) : homeworkList.length === 0 ? (
                        <View style={{ alignItems: 'center', marginTop: 100 }}>
                            <BookOpen size={64} color={COLORS.border} />
                            <Text style={{ marginTop: 16, color: COLORS.gray, fontFamily: 'Poppins-SemiBold' }}>{STRINGS.noDataFound}</Text>
                        </View>
                    ) : (
                        homeworkList.map(item => (
                            <HomeworkItem 
                                key={item.id || item._id}
                                subject={item.subject}
                                title={item.title}
                                dueDate={item.dueDate || 'N/A'}
                                status={item.status}
                                onMarkComplete={() => handleMarkComplete(item)}
                            />
                        ))
                    )}
                </View>
                <View style={{ height: 100 }}/>
            </ScrollView>

            <StatusModal 
                visible={statusModal.visible}
                title={statusModal.title}
                message={statusModal.message}
                type={statusModal.type}
                onClose={() => setStatusModal({ ...statusModal, visible: false })}
                onOk={() => {
                    setStatusModal({ ...statusModal, visible: false });
                    if (statusModal.onOk) statusModal.onOk();
                }}
            />
        </Wrapper>
    );
};

export default StudentHomework;
