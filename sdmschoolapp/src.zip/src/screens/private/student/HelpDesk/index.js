import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Modal, TextInput, FlatList, ActivityIndicator } from 'react-native';
import { ChevronLeft, Plus, MessageCircle, Send, X, AlertCircle } from 'lucide-react-native';
import { useSelector } from 'react-redux';
import { COLORS, APIkit, STRINGS, fontFamily, formatDate } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import Skeleton from '../../../../components/common/Skeleton';
import { StatusModal } from '../../../../components/common/StatusModal';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const HELP_CATEGORIES = [
    "💰 Fee Related",
    "📅 Attendance",
    "📚 Academic / Studies",
    "🚌 Transport",
    "⚙️ Technical Support",
    "📝 Other"
];

const HelpDesk = ({ navigation }) => {
    const { user } = useSelector(state => state.auth);
    const [queries, setQueries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalVisible, setModalVisible] = useState(false);
    const [isPickerVisible, setPickerVisible] = useState(false);
    
    const [formData, setFormData] = useState({
        subject: HELP_CATEGORIES[0],
        message: ''
    });
    const [submitting, setSubmitting] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, type: 'success', title: '', message: '' });

    useEffect(() => {
        fetchQueries();
    }, []);

    const fetchQueries = async () => {
        try {
            const res = await APIkit.get(`student/grievance/${user.id || user._id}`);
            setQueries(res.data);
        } catch (e) {
            console.log("Fetch Queries Error:", e);
            setStatusModal({ 
                visible: true, 
                type: 'error', 
                title: 'FETCH FAILURE', 
                message: e.message || "Failed to load queries from server." 
            });
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        if (!formData.message.trim()) return;
        
        setSubmitting(true);
        await sleep(1000); // Visual commitment delay
        try {
            const res = await APIkit.post('student/grievance', {
                studentId: user.id || user._id,
                studentName: user.name,
                class: user.class,
                section: user.section || 'A',
                subject: formData.subject,
                message: formData.message
            });
            if (res.data) {
                setQueries([res.data, ...queries]);
                setModalVisible(false);
                setFormData({ subject: HELP_CATEGORIES[0], message: '' });
                setStatusModal({ 
                    visible: true, 
                    type: 'success', 
                    title: 'MESSAGE TRANSMITTED', 
                    message: "The institutional teacher has been notified of your query." 
                });
            }
        } catch (e) {
            console.log("Submit Query Error:", e);
            setStatusModal({ 
                visible: true, 
                type: 'error', 
                title: 'TRANSMISSION FAILED', 
                message: e.message || "Failed to deliver message to the teacher hub." 
            });
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Wrapper noTopInset={true} translucent={true} showHeader headerProps={{ title: STRINGS.helpDesk.toUpperCase(), showBack: true }}>
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                <View style={styles.headerRow}>
                    <Text style={styles.title}>{STRINGS.myQueries.toUpperCase()}</Text>
                    <TouchableOpacity style={styles.newBtn} onPress={() => setModalVisible(true)}>
                        <Text style={styles.newBtnText}>{STRINGS.newMsg}</Text>
                    </TouchableOpacity>
                </View>

                {loading ? (
                    [1, 2, 3].map(i => (
                        <View key={i} style={styles.queryCard}>
                            <Skeleton width={100} height={20} borderRadius={4} style={{ marginBottom: 10 }} />
                            <Skeleton width="100%" height={40} borderRadius={8} />
                        </View>
                    ))
                ) : queries.length === 0 ? (
                    <View style={{ alignItems: 'center', marginTop: 100 }}>
                        <MessageCircle size={64} color="#CBD5E1" />
                        <Text style={{ marginTop: 20, color: '#94A3B8', fontFamily: fontFamily.Poppins.ExtraBold }}>{STRINGS.noQueries}</Text>
                        <Text style={{ color: '#94A3B8', fontSize: 12 }}>{STRINGS.helpTagline}</Text>
                    </View>
                ) : (
                    queries.map((item) => (
                        <View key={item.id || item._id} style={styles.queryCard}>
                            <View style={styles.cardHeader}>
                                <View style={styles.subjectBadge}>
                                    <Text style={styles.subjectText}>{item.subject.toUpperCase()}</Text>
                                </View>
                                <View style={[styles.statusBadge, { backgroundColor: item.status === 'RESOLVED' ? '#10B981' : '#F59E0B' }]}>
                                    <Text style={styles.statusText}>{item.status}</Text>
                                </View>
                            </View>
                            <Text style={styles.message}>{item.message}</Text>
                            
                            {item.teacherReply && (
                                <View style={styles.replySection}>
                                    <Text style={styles.replyLabel}>{STRINGS.teacherResponse}</Text>
                                    <Text style={styles.replyText}>{item.teacherReply}</Text>
                                </View>
                            )}
                            
                            <Text style={styles.dateText}>{formatDate(item.date)}</Text>
                        </View>
                    ))
                )}
                <View style={{ height: 100 }} />
            </ScrollView>

            {/* NEW QUERY MODAL */}
            <Modal visible={isModalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={styles.modalTitle}>{STRINGS.newAssistance}</Text>
                            <TouchableOpacity onPress={() => setModalVisible(false)}>
                                <X size={24} color={COLORS.secondary} />
                            </TouchableOpacity>
                        </View>

                        <Text style={styles.label}>{STRINGS.selectCategory}</Text>
                        <TouchableOpacity style={styles.picker} onPress={() => setPickerVisible(true)}>
                            <Text style={styles.pickerText}>{formData.subject}</Text>
                        </TouchableOpacity>

                        <Text style={styles.label}>{STRINGS.yourMessage}</Text>
                        <TextInput
                            style={styles.input}
                            placeholder={STRINGS.msgPlaceholder}
                            multiline
                            value={formData.message}
                            onChangeText={(txt) => setFormData({ ...formData, message: txt })}
                        />

                        <TouchableOpacity 
                            style={[styles.submitBtn, (!formData.message.trim() || submitting) && { opacity: 0.5 }]} 
                            onPress={handleSubmit}
                            disabled={submitting || !formData.message.trim()}
                        >
                            {submitting ? (
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                    <ActivityIndicator size="large" color={COLORS.white} style={{ marginRight: 12 }} />
                                    <Text style={styles.submitBtnText}>{STRINGS.saving}</Text>
                                </View>
                            ) : (
                                <Text style={styles.submitBtnText}>{STRINGS.sendToTeacher}</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>

                {/* CATEGORY PICKER */}
                <Modal visible={isPickerVisible} transparent animationType="fade">
                    <View style={[styles.modalOverlay, { justifyContent: 'center', padding: 40 }]}>
                        <View style={[styles.modalContent, { borderRadius: 24, padding: 0 }]}>
                            <View style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' }}>
                                <Text style={{ fontFamily: fontFamily.Poppins.Black, color: COLORS.secondary }}>{STRINGS.chooseCategory}</Text>
                            </View>
                            <FlatList
                                data={HELP_CATEGORIES}
                                renderItem={({ item }) => (
                                    <TouchableOpacity 
                                        style={styles.categoryItem} 
                                        onPress={() => {
                                            setFormData({ ...formData, subject: item });
                                            setPickerVisible(false);
                                        }}
                                    >
                                        <Text style={styles.categoryText}>{item}</Text>
                                    </TouchableOpacity>
                                )}
                                keyExtractor={item => item}
                            />
                        </View>
                    </View>
                </Modal>
            </Modal>

            <StatusModal
                visible={statusModal.visible}
                type={statusModal.type}
                title={statusModal.title}
                message={statusModal.message}
                onClose={() => setStatusModal({ ...statusModal, visible: false })}
            />
        </Wrapper>
    );
};

export default HelpDesk;
