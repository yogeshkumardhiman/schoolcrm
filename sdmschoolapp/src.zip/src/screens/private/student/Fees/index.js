import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { CreditCard, CheckCircle2, ChevronLeft, Calendar, Bus, Info } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { COLORS, STRINGS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { useDispatch, useSelector } from 'react-redux';
import { getDashboardData } from '../../../../slices/student';
import Skeleton from '../../../../components/common/Skeleton';

const StudentFees = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);
    const [dashboardData, setDashboardData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        dispatch(getDashboardData(user?.admissionNo, (data) => {
            setDashboardData(data);
            setLoading(false);
        }));
    }, [user?.admissionNo]);

    const student = dashboardData?.student;
    const monthlyFees = student?.monthlyFees || [];

    // Calculate Summary
    const totalTuition = monthlyFees.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const totalTransport = student?.usesTransport ? (student.transportFee * 12) : 0;
    const totalFees = totalTuition + totalTransport;

    const paidTuition = monthlyFees.filter(m => m.status === 'PAID').reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const paidFees = paidTuition + (student?.usesTransport ? (student.transportFee * monthlyFees.filter(m => m.status === 'PAID').length) : 0);
    const dueFees = totalFees - paidFees;

    if (loading) {
        return (
            <Wrapper noTopInset={true} translucent={true} showHeader headerProps={{ title: STRINGS.fees, showBack: true }}>
                <View style={{ padding: 24 }}>
                    <View style={{ backgroundColor: '#F1F5F9', borderRadius: 24, padding: 24, marginBottom: 30 }}>
                        <Skeleton width={120} height={16} borderRadius={4} style={{ marginBottom: 12 }} />
                        <Skeleton width={180} height={32} borderRadius={4} style={{ marginBottom: 24 }} />
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <View style={{ flex: 1 }}>
                                <Skeleton width={60} height={12} borderRadius={4} />
                                <Skeleton width={90} height={20} borderRadius={4} style={{ marginTop: 6 }} />
                            </View>
                            <View style={{ flex: 1, alignItems: 'flex-end' }}>
                                <Skeleton width={60} height={12} borderRadius={4} />
                                <Skeleton width={90} height={20} borderRadius={4} style={{ marginTop: 6 }} />
                            </View>
                        </View>
                    </View>
                    <Skeleton width={150} height={24} borderRadius={4} style={{ marginBottom: 20 }} />
                    {[1, 2, 3, 4, 5].map(i => (
                        <View key={i} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12, backgroundColor: '#F8FAFC', padding: 16, borderRadius: 20 }}>
                            <Skeleton width={44} height={44} borderRadius={12} style={{ marginRight: 16 }} />
                            <View style={{ flex: 1 }}>
                                <Skeleton width="60%" height={16} borderRadius={4} style={{ marginBottom: 6 }} />
                                <Skeleton width="40%" height={12} borderRadius={4} />
                            </View>
                            <Skeleton width={60} height={20} borderRadius={4} />
                        </View>
                    ))}
                </View>
            </Wrapper>
        );
    }

    return (
        // <Wrapper noTopInset={true} translucent={true} statusBarColor="transparent" statusBarStyle="light-content">

        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: STRINGS.fees,   // ✅ string
                paddingBottom: 30,             // ✅ comma
                showBack: true,
                // ✅ अगर bottom radius हटाना है
                noBottomRadius: false,

                // ✅ custom styling
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}
        >
            <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                <LinearGradient
                    colors={COLORS.gradient}
                    style={styles.headerGradient}
                >
                   

                    <View style={styles.summaryCard}>
                        <View style={styles.totalRow}>
                            <View>
                                <Text style={styles.totalLabel}>{STRINGS.totalFees.toUpperCase()}</Text>
                                <Text style={styles.totalValue}>₹{totalFees.toLocaleString()}</Text>
                            </View>
                            <CreditCard size={28} color={COLORS.white} opacity={0.6} />
                        </View>
                        <View style={styles.splitStats}>
                            <View style={styles.statBox}>
                                <Text style={styles.statLabel}>{STRINGS.paidFees.toUpperCase()}</Text>
                                <Text style={styles.statValue}>₹{paidFees.toLocaleString()}</Text>
                            </View>
                            <View style={[styles.statBox, { alignItems: 'flex-end' }]}>
                                <Text style={styles.statLabel}>{STRINGS.dueFees.toUpperCase()}</Text>
                                <Text style={[styles.statValue, { color: '#FECACA' }]}>₹{dueFees.toLocaleString()}</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>

                <View style={styles.mainContent}>
                    {/* 🚌 TRANSPORT SECTION */}
                    {student?.usesTransport && (
                        <View style={styles.transportCard}>
                            <View style={[styles.iconBox, { backgroundColor: COLORS.primary + '15' }]}>
                                <Bus size={20} color={COLORS.primary} />
                            </View>
                            <View style={styles.itemInfo}>
                                <Text style={styles.itemName}>{STRINGS.transport}: {student.transportRoute || STRINGS.assignedRoute}</Text>
                                <Text style={styles.itemDate}>{STRINGS.subscribed} • ₹{student.transportFee}/month</Text>
                            </View>
                        </View>
                    )}

                    <Text style={styles.sectionTitle}>{STRINGS.monthlyLedger}</Text>

                    {monthlyFees.map(item => {
                        const isPaid = item.status === 'PAID';
                        const monthTotal = item.amount + (student?.usesTransport ? student.transportFee : 0);

                        return (
                            <View key={item.id} style={[styles.paymentItem, !isPaid && styles.pendingItem]}>
                                <View style={[styles.iconBox, !isPaid && styles.pendingIconBox]}>
                                    {isPaid ? (
                                        <CheckCircle2 size={20} color={COLORS.success} />
                                    ) : (
                                        <Calendar size={20} color={COLORS.error} />
                                    )}
                                </View>
                                <View style={styles.itemInfo}>
                                    <Text style={styles.itemName}>{item.month}</Text>
                                    <Text style={styles.itemDate}>
                                        {isPaid ? STRINGS.paymentConfirmed : STRINGS.pendingPayment}
                                    </Text>
                                </View>
                                <View style={{ alignItems: 'flex-end' }}>
                                    <Text style={[styles.itemAmount, !isPaid && styles.pendingAmount]}>₹{monthTotal}</Text>
                                    {!isPaid && (
                                        <View style={styles.overdueBadge}>
                                            <Text style={styles.overdueText}>{STRINGS.due.toUpperCase()}</Text>
                                        </View>
                                    )}
                                </View>
                            </View>
                        );
                    })}
                </View>
                <View style={{ height: 100 }} /></ScrollView>
        </Wrapper>
    );
};

export default StudentFees;
