import { StyleSheet } from 'react-native';
import { fontFamily, COLORS } from '../../../../utils';


export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    headerGradient: {
        paddingTop: 60,
        paddingBottom: 40,
        paddingHorizontal: 24,
        borderBottomLeftRadius: 40,
        borderBottomRightRadius: 40,
    },
    backBtn: {
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 24,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
        marginBottom: 24,
    },
    summaryCard: {
        backgroundColor: 'rgba(255,255,255,0.15)',
        borderRadius: 24,
        padding: 24,
    },
    totalRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
        paddingBottom: 20,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255,255,255,0.1)',
    },
    totalLabel: {
        fontSize: 12,
        fontFamily: fontFamily.Poppins.Bold,
        color: 'rgba(255,255,255,0.7)',
    },
    totalValue: {
        fontSize: 24,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
    },
    splitStats: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    statBox: {
        flex: 1,
    },
    statLabel: {
        fontSize: 9,
        fontFamily: fontFamily.Poppins.Bold,
        color: 'rgba(255,255,255,0.7)',
        marginBottom: 4,
    },
    statValue: {
        fontSize: 16,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
    },
    // 💰 CONTENT
    mainContent: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 30,
    },
    sectionTitle: {
        fontSize: 18,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.secondary,
        marginBottom: 20,
        letterSpacing: -0.5,
    },
    paymentItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F1F5F9',
        padding: 16,
        borderRadius: 20,
        marginBottom: 12,
    },
    iconBox: {
        width: 44,
        height: 44,
        backgroundColor: '#DCFCE7',
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16,
    },
    itemInfo: {
        flex: 1,
    },
    itemName: {
        fontSize: 14,
        fontFamily: fontFamily.Poppins.ExtraBold,
        color: COLORS.secondary,
    },
    itemDate: {
        fontSize: 11,
        fontFamily: fontFamily.Poppins.SemiBold,
        color: COLORS.gray,
        marginTop: 2,
    },
    itemAmount: {
        fontSize: 14,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.success,
    },
    // 🚌 NEW STYLES
    transportCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: COLORS.white,
        padding: 16,
        borderRadius: 20,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: COLORS.primary + '20',
        borderStyle: 'dashed',
    },
    pendingItem: {
        backgroundColor: '#FFF1F2',
    },
    pendingIconBox: {
        backgroundColor: '#FFE4E6',
    },
    pendingAmount: {
        color: COLORS.error,
    },
    overdueBadge: {
        backgroundColor: COLORS.error,
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 6,
        marginTop: 4,
    },
    overdueText: {
        fontSize: 8,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.white,
        letterSpacing: 1,
    }
});
