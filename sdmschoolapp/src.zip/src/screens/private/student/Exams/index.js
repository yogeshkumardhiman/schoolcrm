import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, ActivityIndicator } from 'react-native';
import { Award, GraduationCap } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { COLORS, STRINGS, APIkit, API_END_POINTS, width, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { useSelector } from 'react-redux';
import Skeleton from '../../../../components/common/Skeleton';

const StudentExams = ({ navigation }) => {
    const { user } = useSelector(state => state.auth);
    const [performanceData, setPerformanceData] = useState([]);
    const [overallScore, setOverallScore] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchResults = async () => {
            if (!user?.id && !user?._id) return;
            try {
                setLoading(true);
                const res = await APIkit.get(`${API_END_POINTS.studentResults}/${user?.id || user?._id}`);
                const rawMarks = res.data || [];

                const colors = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
                const subjectSummary = {};

                rawMarks.forEach(m => {
                    const subName = m.subject?.toUpperCase() || "UNKNOWN";
                    if (!subjectSummary[subName]) subjectSummary[subName] = { obtained: 0, total: 0 };
                    subjectSummary[subName].obtained += Number(m.marks || 0);
                    subjectSummary[subName].total += Number(m.total || 100);
                });

                const formatted = Object.keys(subjectSummary).map((sub, idx) => {
                    const data = subjectSummary[sub];
                    const percentage = data.total > 0 ? Math.round((data.obtained / data.total) * 100) : 0;
                    return { subject: sub, score: data.obtained, outOf: data.total, percentage, color: colors[idx % colors.length] };
                });

                setPerformanceData(formatted);
                if (formatted.length > 0) {
                    const avg = formatted.reduce((acc, curr) => acc + curr.percentage, 0) / formatted.length;
                    setOverallScore(Math.round(avg));
                }
            } catch (e) {
                console.log("⚓ API Sync Failure:", e);
            } finally {
                setLoading(false);
            }
        };
        fetchResults();
    }, [user?.id, user?._id]);

    const ProgressBar = ({ progress, color }) => (
        <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${progress}%`, backgroundColor: color }]} />
        </View>
    );

    return (
        <Wrapper

            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
               
                title: STRINGS.academicPerformance,   // ✅ string
                paddingBottom: 20,             // ✅ comma

                // ✅ अगर bottom radius हटाना है
                noBottomRadius: false,

                // ✅ custom styling
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}>
            <View style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                    <LinearGradient colors={COLORS.gradient} style={styles.headerGradient}>
                        <View style={styles.summaryCard}>
                            <View>
                                <Text style={styles.summaryLabel}>{STRINGS.overallPerformance.toUpperCase()}</Text>
                                <Text style={styles.overallValue}>{overallScore}%</Text>
                            </View>
                            <View style={styles.medalBox}><Award size={32} color={COLORS.primary} /></View>
                        </View>
                    </LinearGradient>

                    <View style={styles.mainContent}>
                        {loading ? (
                            <View style={{ padding: 20 }}>
                                <View style={styles.chartSection}>
                                    <Skeleton width="100%" height={160} borderRadius={24} />
                                </View>
                                {[1, 2, 3].map(i => (
                                    <View key={i} style={styles.subjectCard}>
                                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 }}>
                                            <Skeleton width={120} height={16} borderRadius={4} />
                                            <Skeleton width={60} height={16} borderRadius={4} />
                                        </View>
                                        <Skeleton width="100%" height={8} borderRadius={4} style={{ marginBottom: 10 }} />
                                        <Skeleton width={40} height={12} borderRadius={4} />
                                    </View>
                                ))}
                            </View>
                        ) : performanceData.length === 0 ? (
                            <Text style={{ textAlign: 'center', marginTop: 40, color: '#cbd5e1', fontFamily: fontFamily.Poppins.Bold }}>{STRINGS.noDataFound}</Text>
                        ) : (
                            <>
                                <View style={styles.chartSection}>
                                    <View style={styles.sectionHeader}>
                                        <GraduationCap size={20} color={COLORS.primary} />
                                        <Text style={styles.sectionTitle}>{STRINGS.subjectWise.toUpperCase()}</Text>
                                    </View>
                                    <View style={styles.chartContainer}>
                                        {performanceData.map((item, index) => (
                                            <View key={index} style={styles.chartBarWrapper}>
                                                <View style={[styles.chartBar, { height: Math.max((item.percentage / 100) * 120, 5), backgroundColor: item.color }]} />
                                                <Text style={styles.chartLabel} numberOfLines={1}>{item.subject.substring(0, 4)}</Text>
                                            </View>
                                        ))}
                                    </View>
                                </View>
                                {performanceData.map((item, index) => (
                                    <View key={index} style={styles.subjectCard}>
                                        <View style={styles.subjectHeader}>
                                            <Text style={styles.subjectName}>{item.subject}</Text>
                                            <Text style={styles.marksText}>{item.score}/{item.outOf}</Text>
                                        </View>
                                        <ProgressBar progress={item.percentage} color={item.color} />
                                        <Text style={styles.percentageText}>{item.percentage}%</Text>
                                    </View>
                                ))}
                            </>
                        )}
                        <View style={{ height: 100 }} />
                    </View>
                </ScrollView>
            </View>
        </Wrapper>
    );
};

export default StudentExams;
