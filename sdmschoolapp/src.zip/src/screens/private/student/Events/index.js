import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Trophy, Clock, MapPin, Users, ChevronLeft, Share2 } from 'lucide-react-native';
import LinearGradient from 'react-native-linear-gradient';
import { COLORS, STRINGS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';

const StudentEvents = ({ navigation }) => {
    const [events, setEvents] = React.useState([]);

    React.useEffect(() => {
        const fetchEvents = async () => {
            try {
                const res = await APIkit.get(API_END_POINTS.events);
                setEvents(res.data);
            } catch (e) {
                console.log("⚓ Event Fetch Failure:", e);
            }
        };
        fetchEvents();
    }, []);

    return (

        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                showBack: true,
                title: STRINGS.schoolEvents,
                paddingBottom: 40,
                noBottomRadius: false,
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}
        >

            {/* <Wrapper noTopInset={true} translucent={true} statusBarColor="transparent" statusBarStyle="light-content"> */}
            <View style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>


                    <View style={styles.mainContent}>
                        {events.map(item => (
                            <View key={item.id} style={styles.eventCardDetail}>
                                <View style={[styles.eventHeader, { backgroundColor: item.color }]}>
                                    <Trophy size={20} color={COLORS.white} />
                                    <View style={styles.eventHeaderInfo}>
                                        <Text style={styles.eventTitleDetail}>{item.title}</Text>
                                        <Text style={styles.eventDateDetail}>{item.date}</Text>
                                    </View>
                                </View>

                                <View style={styles.eventBody}>
                                    <View style={styles.detailRow}>
                                        <View style={styles.iconBox}>
                                            <Clock size={18} color="#94A3B8" />
                                        </View>
                                        <View>
                                            <Text style={styles.detailLabel}>{STRINGS.time}</Text>
                                            <Text style={styles.detailValue}>{item.time}</Text>
                                        </View>
                                    </View>

                                    <View style={styles.detailRow}>
                                        <View style={styles.iconBox}>
                                            <MapPin size={18} color="#94A3B8" />
                                        </View>
                                        <View>
                                            <Text style={styles.detailLabel}>{STRINGS.location}</Text>
                                            <Text style={styles.detailValue}>{item.location}</Text>
                                        </View>
                                    </View>

                                    <View style={styles.detailRow}>
                                        <View style={styles.iconBox}>
                                            <Users size={18} color="#94A3B8" />
                                        </View>
                                        <View>
                                            <Text style={styles.detailLabel}>{STRINGS.participants}</Text>
                                            <Text style={styles.detailValue}>{item.participants}</Text>
                                        </View>
                                    </View>
                                </View>

                            </View>
                        ))}
                    </View>
                    <View style={{ height: 120 }} />
                </ScrollView>
            </View>
        </Wrapper>
    );
};

export default StudentEvents;
