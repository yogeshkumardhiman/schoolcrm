import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Bell, Calendar, TrendingUp, IndianRupee, Trophy, Music, Users, MessageCircle, ChevronRight, BookOpen } from 'lucide-react-native';

import { useDispatch, useSelector } from 'react-redux';
import { COLORS, getResolvedUrl, STRINGS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import StatCard from '../../../../components/Cards/StatCard';
import EventItem from '../../../../components/Cards/EventItem';
import { getDashboardData } from '../../../../slices/student';
import { APIService } from '../../../../services/APIServices';

import Skeleton from '../../../../components/common/Skeleton';

const StudentDashboard = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);
    const [schoolInfo, setSchoolInfo] = useState(null);
    const [dashboardData, setDashboardData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        const fetchTelemetry = async () => {
            // Fetch School Info through Service layer
            new APIService().getSchoolInfo().then(res => {
                if(res?.status === 200) setSchoolInfo(res.data);
            });

            // Fetch Student Dashboard through Slice thunk
            dispatch(getDashboardData(user?.admissionNo, (data) => {
                if(data) setDashboardData(data);
                setLoading(false);
            }));
        };
        fetchTelemetry();
    }, [user?.admissionNo]);

    const upcomingEvents = [
        { id: 1, title: 'Science Fair', date: 'Apr 15, 2026', icon: Trophy, color: COLORS.primary },
        { id: 2, title: 'Sports Day', date: 'Apr 22, 2026', icon: Music, color: COLORS.accent },
        { id: 3, title: 'Parent Meeting', date: 'Apr 28, 2026', icon: Users, color: '#10B981' },
    ];

    const getInitials = (name) => {
        if (!name) return "RK"; // Default from Figma
        return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
    }

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                renderContent: () => (
                    <View style={styles.headerTop}>
                        {loading ? (
                            <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                                <Skeleton width={60} height={60} borderRadius={30} style={{ marginRight: 16 }} />
                                <View style={{ flex: 1 }}>
                                    <Skeleton width="70%" height={20} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="40%" height={14} borderRadius={4} />
                                </View>
                            </View>
                        ) : (
                            <>
                                <View style={styles.profileInitial}>
                                    {user?.image ? (
                                        <Image source={{ uri: getResolvedUrl(user.image) }} style={{ width: '100%', height: '100%', borderRadius: 50, borderWidth: 2, borderColor: COLORS.white, resizeMode: 'contain' }} />
                                    ) : (
                                        <Text style={styles.profileInitialText}>{getInitials(user?.name)}</Text>
                                    )}
                                </View>
                                <View style={styles.studentInfo}>
                                    <Text style={styles.studentName}>{dashboardData?.student?.name || user?.name || 'Rahul Kumar'}</Text>
                                    <Text style={styles.studentClass}>
                                        {STRINGS.class} {dashboardData?.student?.class || user?.class || '10-A'} • {STRINGS.rollNo}: {dashboardData?.student?.rollNo || user?.rollNo || '23'}
                                    </Text>
                                    <Text style={styles.schoolName}>{schoolInfo?.school_name || STRINGS.appName}</Text>
                                </View>
                            </>
                        )}
                        <TouchableOpacity style={styles.notificationBtn}>
                            <Bell size={22} color={COLORS.white} />
                            <View style={styles.notificationBadge}>
                                <Text style={styles.badgeText}>3</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                )
            }}
        >
            <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
                <View style={styles.statsRow}>
                    {loading ? (
                        [1, 2, 3].map(i => (
                            <View key={i} style={{ flex: 1, marginHorizontal: 4 }}>
                                <Skeleton width="100%" height={100} borderRadius={16} />
                            </View>
                        ))
                    ) : (
                        <>
                            <StatCard
                                Icon={Calendar}
                                label={STRINGS.attendance}
                                value={dashboardData?.stats?.attendance || "92%"}
                                color="#3B82F6"
                                onPress={() => navigation.navigate('ActivityScreen')}
                            />
                            <StatCard
                                Icon={BookOpen}
                                label={STRINGS.homework}
                                value={`${dashboardData?.stats?.homeworkPending || 0} ${STRINGS.pending}`}
                                color="#F59E0B"
                                onPress={() => navigation.navigate('StudentHomework')}
                            />
                            <StatCard
                                Icon={TrendingUp}
                                label={STRINGS.avgMarks}
                                value={dashboardData?.stats?.avgMarks || "85%"}
                                color="#8B5CF6"
                                onPress={() => navigation.navigate('MarksScreen')}
                            />
                            <StatCard
                                Icon={IndianRupee}
                                label={STRINGS.feeStatus}
                                value={dashboardData?.stats?.feesStatus || STRINGS.paid}
                                color={COLORS.success}
                                onPress={() => navigation.navigate('StudentFees')}
                            />
                        </>
                    )}
                </View>

                <View style={styles.mainContent}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>{STRINGS.upcomingEvents}</Text>
                        <TouchableOpacity onPress={() => navigation.navigate('StudentEvents')}>
                            <Text style={styles.viewAllLink}>{STRINGS.viewAll}</Text>
                        </TouchableOpacity>
                    </View>

                    {upcomingEvents.map(event => (
                        <EventItem
                            key={event.id}
                            title={event.title}
                            date={event.date}
                            icon={event.icon}
                            color={event.color}
                        />
                    ))}

                    {/* 🛡️ ADMIN UPDATES SECTION */}
                    <View style={styles.adminUpdateCard}>
                        <View style={styles.adminIconBox}>
                            <Bell size={24} color={COLORS.primary} strokeWidth={2} />
                        </View>
                        <View style={styles.adminInfo}>
                            <Text style={styles.adminTitle}>{STRINGS.adminUpdates}</Text>
                            <Text style={styles.adminDesc}>{STRINGS.adminUpdateDesc}</Text>
                        </View>
                    </View>

                    {/* 👨‍🏫 CLASS TEACHER SECTION */}
                    {dashboardData?.stats?.classTeacher && (
                        <View style={[styles.adminUpdateCard, { marginTop: 20, borderColor: COLORS.accent + '20', backgroundColor: COLORS.accent + '05' }]}>
                            <View style={[styles.adminIconBox, { backgroundColor: COLORS.accent + '10' }]}>
                                {dashboardData.stats.classTeacher.image ? (
                                    <Image source={{ uri: dashboardData.stats.classTeacher.image }} style={{ width: '100%', height: '100%', borderRadius: 12 }} />
                                ) : (
                                    <Users size={24} color={COLORS.accent} strokeWidth={2} />
                                )}
                            </View>
                            <View style={styles.adminInfo}>
                                <Text style={[styles.adminTitle, { color: COLORS.accent }]}>{STRINGS.classTeacher}</Text>
                                <Text style={styles.adminDesc}>{dashboardData.stats.classTeacher.name} • {dashboardData.stats.classTeacher.phone}</Text>
                            </View>
                        </View>
                    )}

                    {/* 🆘 HELP DESK ACCESS */}
                    <TouchableOpacity 
                        style={[styles.adminUpdateCard, { marginTop: 20, borderColor: COLORS.primary + '30', backgroundColor: COLORS.primary + '03' }]}
                        onPress={() => navigation.navigate('HelpDesk')}
                    >
                        <View style={[styles.adminIconBox, { backgroundColor: COLORS.primary + '10' }]}>
                            <MessageCircle size={24} color={COLORS.primary} strokeWidth={2.5} />
                        </View>
                        <View style={styles.adminInfo}>
                            <Text style={styles.adminTitle}>{STRINGS.helpDesk.toUpperCase()}</Text>
                            <Text style={styles.adminDesc}>{STRINGS.helpDeskDesc}</Text>
                        </View>
                        <View style={{ justifyContent: 'center' }}>
                            <ChevronRight size={20} color={COLORS.primary} />
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={{ height: 120 }} />
            </ScrollView>
        </Wrapper>
    );
};

export default StudentDashboard;
