import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Modal, TextInput, ActivityIndicator } from 'react-native';
import { ChevronLeft, Plus, ClipboardList, Calendar, Award, X, Save } from 'lucide-react-native';
import { useSelector } from 'react-redux';
import { COLORS, APIkit, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { CustomButton } from '../../../../components/CustomButton';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const TestList = ({ navigation }) => {
    const { user } = useSelector(state => state.auth);
    const [tests, setTests] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    
    // New Exam State
    const [newExam, setNewExam] = useState({
        title: '',
        subject: user?.subject || '',
        maxMarks: '50',
        date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase(),
        class: user?.class || '10TH'
    });

    const fetchExams = async () => {
        setLoading(true);
        try {
            const res = await APIkit.get(`teacher/exams/${user?.class || '10TH'}`);
            setTests(res.data);
        } catch (e) {
            console.log("⚓ Exam Fetch Failure:", e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchExams();
    }, [user?.class]);

    const handleAddExam = async () => {
        if(!newExam.title || !newExam.subject) return;
        setIsSubmitting(true);
        await sleep(1000); // Visual commitment delay
        try {
            await APIkit.post('teacher/exams', {
                ...newExam,
                maxMarks: parseInt(newExam.maxMarks)
            });
            setModalVisible(false);
            fetchExams();
        } catch (e) {
            console.log("⚓ Exam Creation Failure:", e);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: "EXAM REGISTRY",
                showBack: true,
                paddingBottom: 45
            }}
        >

            {loading ? (
                <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator color={COLORS.primary} /></View>
            ) : (
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 24, paddingTop: 32, paddingBottom: 100 }}>
                    <View style={styles.listHeader}>
                        <Text style={styles.listTitle}>ACTIVE PROTOCOLS</Text>
                        <Text style={styles.countText}>{tests.length} MODULES</Text>
                    </View>

                    {tests.map((test) => (
                        <TouchableOpacity 
                            key={test.id} 
                            style={styles.testCard}
                            onPress={() => navigation.navigate('AddMarks', { test: { ...test, name: test.title, max: test.maxMarks.toString() } })}
                        >
                            <View style={styles.testHeader}>
                                <View style={[styles.testBadge, { backgroundColor: test.status === 'COMPLETED' ? '#F0FDF4' : test.status === 'MARKING' ? '#FFFBEB' : '#EFF6FF' }]}>
                                    <Text style={[styles.testBadgeText, { color: test.status === 'COMPLETED' ? '#16A34A' : test.status === 'MARKING' ? '#D97706' : '#2563EB' }]}>{test.status || 'MARKING'}</Text>
                                </View>
                                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                                    <Calendar size={12} color={COLORS.gray} />
                                    <Text style={styles.testDate}>{test.date}</Text>
                                </View>
                            </View>
                            
                            <Text style={styles.testTitle}>{test.title}</Text>
                            
                            <View style={styles.testMeta}>
                                <View style={styles.metaItem}>
                                    <ClipboardList size={14} color={COLORS.primary} />
                                    <Text style={styles.metaText}>{test.subject}</Text>
                                </View>
                                <View style={styles.metaItem}>
                                    <Award size={14} color={COLORS.accent} />
                                    <Text style={styles.metaText}>MAX: {test.maxMarks}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    ))}
                </ScrollView>
            )}

            <TouchableOpacity style={styles.fab} activeOpacity={0.8} onPress={() => setModalVisible(true)}>
                <Plus size={28} color={COLORS.white} />
            </TouchableOpacity>

            {/* 🏗️ CREATE EXAM MODAL */}
            <Modal visible={modalVisible} animationType="slide" transparent={true}>
                <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
                    <View style={{ backgroundColor: '#fff', borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 32, minHeight: '60%' }}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
                            <Text style={{ fontSize: 20, fontFamily: fontFamily.Poppins.Black, color: COLORS.secondary }}>NEW ASSESSMENT</Text>
                            <TouchableOpacity onPress={() => setModalVisible(false)}><X size={24} color={COLORS.secondary} /></TouchableOpacity>
                        </View>

                        <View style={{ gap: 20 }}>
                            <View>
                                <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.Black, color: COLORS.gray, marginBottom: 8, letterSpacing: 1 }}>EXAM TITLE (UNIT 1, HALF-YEARLY)</Text>
                                <TextInput 
                                    value={newExam.title} 
                                    onChangeText={t => setNewExam({...newExam, title: t})}
                                    placeholder="EX: UNIT TEST 1"
                                    style={{ borderBottomWidth: 1, borderColor: '#eee', paddingVertical: 12, fontSize: 16, fontFamily: fontFamily.Poppins.Bold, color: COLORS.secondary }}
                                />
                            </View>

                            <View>
                                <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.Black, color: COLORS.gray, marginBottom: 8, letterSpacing: 1 }}>SUBJECT HUB</Text>
                                <TextInput 
                                    value={newExam.subject} 
                                    onChangeText={t => setNewExam({...newExam, subject: t})}
                                    placeholder="EX: MATHEMATICS"
                                    style={{ borderBottomWidth: 1, borderColor: '#eee', paddingVertical: 12, fontSize: 16, fontFamily: fontFamily.Poppins.Bold, color: COLORS.secondary }}
                                />
                            </View>

                            <View style={{ flexDirection: 'row', gap: 20 }}>
                                <View style={{ flex: 1 }}>
                                    <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.Black, color: COLORS.gray, marginBottom: 8, letterSpacing: 1 }}>MAX SCORE</Text>
                                    <TextInput 
                                        value={newExam.maxMarks} 
                                        onChangeText={t => setNewExam({...newExam, maxMarks: t})}
                                        keyboardType="numeric"
                                        style={{ borderBottomWidth: 1, borderColor: '#eee', paddingVertical: 12, fontSize: 16, fontFamily: fontFamily.Poppins.Bold, color: COLORS.secondary }}
                                    />
                                </View>
                                <View style={{ flex: 1 }}>
                                    <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.Black, color: COLORS.gray, marginBottom: 8, letterSpacing: 1 }}>SCHEDULED DATE</Text>
                                    <TextInput 
                                        value={newExam.date} 
                                        onChangeText={t => setNewExam({...newExam, date: t})}
                                        style={{ borderBottomWidth: 1, borderColor: '#eee', paddingVertical: 12, fontSize: 16, fontFamily: fontFamily.Poppins.Bold, color: COLORS.secondary }}
                                    />
                                </View>
                            </View>

                            <CustomButton 
                                title="ARCHITECT ASSESSMENT"
                                onPress={handleAddExam}
                                icon={Save}
                                variant="commit"
                                style={{ marginTop: 24 }}
                                loading={isSubmitting}
                            />
                        </View>
                    </View>
                </View>
            </Modal>
        </Wrapper>
    );
};

export default TestList;
