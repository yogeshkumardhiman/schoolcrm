import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Image, Alert } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS,fontFamily} from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { CustomButton } from '../../../../components/CustomButton';
import { StatusModal } from '../../../../components/common/StatusModal';
import { getClassRegistry, uploadBulkMarks } from '../../../../slices/teacher';


const AddMarks = ({ navigation, route }) => {
    const dispatch = useDispatch();
    const insets = useSafeAreaInsets();
    const { user } = useSelector(state => state.auth);
    const { test } = route.params || { test: { name: 'UT-1', subject: 'Maths', max: '50' } };

    const [students, setStudents] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, type: 'success', title: '', message: '', onConfirm: null });

    React.useEffect(() => {
        setIsLoading(true);
        const targetClass = user?.class || 'UKG';
        dispatch(getClassRegistry(targetClass, (data) => {
            if (data) {
                setStudents(data.map(s => ({
                    id: s.id || s._id,
                    name: s.name,
                    roll: s.admissionNo || s.rollNo,
                    marks: '',
                    image: s.image || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + s.name
                })));
            }
            setIsLoading(false);
        }));
    }, [user?.class]);

    const handleCommit = async () => {
        if (isSubmitting) return;

        try {
            const hasEmptyMarks = students.some(s => !s.marks);
            if (hasEmptyMarks) {
                setStatusModal({
                    visible: true,
                    type: 'error',
                    title: 'PENDING MARKS',
                    message: "Please ensure all scholars have been assigned a score before commitment."
                });
                return;
            }

            setIsSubmitting(true);
            const results = students.map(s => ({
                studentId: s.id,
                subject: test.subject,
                score: parseInt(s.marks) || 0,
                outOf: parseInt(test.max) || 100,
                examType: test.name
            }));
            
            dispatch(uploadBulkMarks({ results }, (res) => {
                setIsSubmitting(false);
                if (res) {
                    setStatusModal({
                        visible: true,
                        type: 'success',
                        title: 'REGISTRY UPDATED',
                        message: 'Scores have been successfully committed to the institutional vault.',
                        onConfirm: () => navigation.goBack()
                    });
                } else {
                    setStatusModal({
                        visible: true,
                        type: 'error',
                        title: 'COMMITMENT FAILED',
                        message: 'The institutional vault rejected the scores. Please verify connectivity.'
                    });
                }
            }));
        } catch (e) {
            setIsSubmitting(false);
            setStatusModal({
                visible: true,
                type: 'error',
                title: 'SUBSYSTEM FAILURE',
                message: "An unexpected error occurred during score commitment."
            });
            console.log("⚓ Result Commitment Failure:", e);
        }
    };

    const handleMarkChange = (id, value) => {
        setStudents(prev => prev.map(s => s.id === id ? { ...s, marks: value } : s));
    };

    const calculatePercentage = (marks) => {
        const m = parseFloat(marks) || 0;
        const total = parseFloat(test.max) || 100;
        return ((m / total) * 100).toFixed(1);
    };

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: "SCORE ALLOCATION",
                showBack: true,
                paddingBottom: 45,
                children: (
                    <View style={{ alignSelf: 'center', marginTop: 10, alignItems: 'center' }}>
                        <Text style={{ fontSize: 18, fontFamily: fontFamily.Poppins.Black, color: COLORS.white }}>{test.name}</Text>
                        <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.SemiBold, color: 'rgba(255,255,255,0.7)', letterSpacing: 1 }}>{test.subject} • MAX {test.max}</Text>
                    </View>
                )
            }}
        >

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                {/* 📝 SCHOLAR REGISTRY Marks */}
                <View style={styles.listHeader}>
                    <Text style={styles.listTitle}>FLEET PERFORMANCE</Text>
                    <Text style={styles.countText}>{students.length} SCHOLARS</Text>
                </View>

                {students.map((student) => {
                    const percent = calculatePercentage(student.marks);
                    const isHigh = parseFloat(percent) >= 80;

                    return (
                        <View key={student.id} style={styles.studentCard}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                                <Image source={{ uri: student.image }} style={styles.studentAvatar} />
                                <View style={styles.studentInfo}>
                                    <Text style={styles.studentName}>{student.name}</Text>
                                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                                        <Text style={styles.studentRoll}>{student.roll}</Text>
                                        <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: COLORS.border }} />
                                        <Text style={{ fontSize: 10, fontFamily: fontFamily.Poppins.Black, color: isHigh ? COLORS.green : COLORS.accent }}>{percent}%</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.inputContainer}>
                                <TextInput
                                    style={styles.markInput}
                                    value={student.marks}
                                    onChangeText={(val) => handleMarkChange(student.id, val)}
                                    keyboardType="numeric"
                                    maxLength={3}
                                />
                                <Text style={styles.maxValue}>/{test.max}</Text>
                            </View>
                        </View>
                    );
                })}
                <View style={{ height: 100 }} />
            </ScrollView>

            {/* 🚀 COMMIT ACTION */}
            <View style={{ paddingHorizontal: 24, paddingBottom: 40 }}>
                <CustomButton 
                    title="COMMIT ASSESSMENT LOG"
                    variant="commit"
                    icon={Save}
                    onPress={handleCommit}
                    loading={isSubmitting}
                />
            </View>

            <StatusModal
                visible={statusModal.visible}
                type={statusModal.type}
                title={statusModal.title}
                message={statusModal.message}
                onClose={() => setStatusModal({ ...statusModal, visible: false })}
                onOk={() => {
                    setStatusModal({ ...statusModal, visible: false });
                    if (statusModal.onConfirm) statusModal.onConfirm();
                }}
            />
        </Wrapper>
    );
};

export default AddMarks;
