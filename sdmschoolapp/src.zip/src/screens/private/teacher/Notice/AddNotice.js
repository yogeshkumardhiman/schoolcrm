import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { ChevronLeft, Send, Bell, Users, LayoutGrid, Info, Megaphone } from 'lucide-react-native';
import { useDispatch, useSelector } from 'react-redux';
import { COLORS, STRINGS, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { broadcastClassNotice } from '../../../../slices/teacher';
import { StatusModal } from '../../../../components/common/StatusModal';

const AddNotice = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [target, setTarget] = useState('class'); // 'class' or 'school'
    const [category, setCategory] = useState('General');
    const [submitting, setSubmitting] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, type: 'info', title: '', message: '', onConfirm: null });

    const categories = ['General', 'Urgent', 'Holiday', 'Event'];

    const handlePost = async () => {
        if (!title.trim() || !content.trim()) {
            setStatusModal({
                visible: true,
                type: 'error',
                title: 'MISSING INFORMATION',
                message: STRINGS.provideTitleContent
            });
            return;
        }

        const targetGroup = target === 'class' ? `Class ${user?.class || '10TH'}-${user?.section || 'A'}` : STRINGS.entireSchool.toLowerCase();

        setStatusModal({
            visible: true,
            type: 'info',
            title: 'BROADCAST CONFIRMATION',
            message: `${STRINGS.releaseToTarget} ${targetGroup}?`,
            showCancel: true,
            okTitle: STRINGS.release,
            onConfirm: () => {
                const payload = {
                    senderId: user?.id || user?._id,
                    class: target === 'class' ? user?.class : 'ALL',
                    section: target === 'class' ? user?.section : 'ALL',
                    title: title,
                    message: content,
                    type: category,
                    senderName: user?.name
                };
                setSubmitting(true);
                dispatch(broadcastClassNotice(payload, (res) => {
                    setSubmitting(false);
                    if (res) {
                        setStatusModal({
                            visible: true,
                            type: 'success',
                            title: 'BROADCAST SUCCESS',
                            message: 'Notice has been successfully transmitted to the institutional registry.',
                            onConfirm: () => navigation.goBack()
                        });
                    }
                }));
            }
        });
    };

    return (

        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: STRINGS.noticeEmitter,
                paddingBottom: 20,
                showBack: true,
                containerStyle: {
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                }
            }}
        >
            {/* 🧭 NAVIGATION HEADER */}
            <View style={styles.header}>


                <View style={styles.targetSwitcher}>
                    <TouchableOpacity
                        onPress={() => setTarget('class')}
                        style={[styles.targetBtn, target === 'class' && styles.targetActive]}
                    >
                        <Users size={16} color={target === 'class' ? COLORS.primary : COLORS.white} />
                        <Text style={[styles.targetText, target === 'class' && { color: COLORS.primary }]}>{STRINGS.myClass} ({user?.class || '10TH'}-{user?.section || 'A'})</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setTarget('school')}
                        style={[styles.targetBtn, target === 'school' && styles.targetActive]}
                    >
                        <LayoutGrid size={16} color={target === 'school' ? COLORS.primary : COLORS.white} />
                        <Text style={[styles.targetText, target === 'school' && { color: COLORS.primary }]}>{STRINGS.entireSchool}</Text>
                    </TouchableOpacity>
                </View>
            </View>

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={{ flex: 1 }}
            >
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>

                    {/* 🏷️ CATEGORY SELECTOR */}
                    <Text style={styles.sectionTitle}>{STRINGS.selectCategory}</Text>
                    <View style={styles.categoryRow}>
                        {categories.map((cat) => (
                            <TouchableOpacity
                                key={cat}
                                onPress={() => setCategory(cat)}
                                style={[styles.categoryPill, category === cat && styles.categoryActive]}
                            >
                                <Text style={[styles.categoryText, category === cat && styles.categoryActiveText]}>{cat.toUpperCase()}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>

                    {/* 📝 NOTICE FORM */}
                    <View style={styles.formCard}>
                        <View style={styles.inputGroup}>
                            <Text style={styles.inputLabel}>{STRINGS.noticeTitleLabel}</Text>
                            <TextInput
                                placeholder="e.g. Schedule Revision for Mondays"
                                style={styles.titleInput}
                                placeholderTextColor={COLORS.gray}
                                value={title}
                                onChangeText={setTitle}
                            />
                        </View>

                        <View style={styles.divider} />

                        <View style={styles.inputGroup}>
                            <Text style={styles.inputLabel}>{STRINGS.noticeContentLabel}</Text>
                            <TextInput
                                placeholder="Detailed administrative content..."
                                style={styles.contentInput}
                                placeholderTextColor={COLORS.gray}
                                multiline
                                numberOfLines={8}
                                textAlignVertical="top"
                                value={content}
                                onChangeText={setContent}
                            />
                        </View>
                    </View>

                    <View style={styles.guaranteeBox}>
                        <Info size={18} color={COLORS.secondary} />
                        <Text style={styles.guaranteeText}>{STRINGS.instantBroadcastMsg}</Text>
                    </View>

                </ScrollView>

                {/* 🚀 EMISSION ACTION */}
                <View style={styles.footer}>
                    <TouchableOpacity 
                        onPress={handlePost} 
                        style={[styles.emitButton, submitting && { opacity: 0.7 }]}
                        disabled={submitting}
                    >
                        {submitting ? (
                            <ActivityIndicator size="large" color={COLORS.white} />
                        ) : (
                            <>
                                <Text style={styles.emitText}>{STRINGS.releaseNotice}</Text>
                                <Megaphone size={20} color={COLORS.white} />
                            </>
                        )}
                    </TouchableOpacity>
                </View>

                <StatusModal
                    visible={statusModal.visible}
                    type={statusModal.type}
                    title={statusModal.title}
                    message={statusModal.message}
                    showCancel={statusModal.showCancel}
                    okTitle={statusModal.okTitle}
                    onClose={() => setStatusModal({ ...statusModal, visible: false })}
                    onOk={() => {
                        setStatusModal({ ...statusModal, visible: false });
                        if (statusModal.onConfirm) statusModal.onConfirm();
                    }}
                />
            </KeyboardAvoidingView>
        </Wrapper>
    );
};

export default AddNotice;
