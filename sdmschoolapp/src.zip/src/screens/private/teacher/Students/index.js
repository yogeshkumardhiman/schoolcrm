import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Image } from 'react-native';
import { ChevronLeft, Search, Plus, Edit3, Trash2, GraduationCap } from 'lucide-react-native';
import { useDispatch, useSelector } from 'react-redux';
import { COLORS, APIkit, API_END_POINTS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { getClassRegistry } from '../../../../slices/teacher';
import Skeleton from '../../../../components/common/Skeleton';

const StudentRegistry = ({ navigation }) => {
    const dispatch = useDispatch();
    const { user, role } = useSelector(state => state.auth);
    const isAdmin = role?.toLowerCase() === 'admin';
    const [searchQuery, setSearchQuery] = useState('');
    const [students, setStudents] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    React.useEffect(() => {
        setIsLoading(true);
        if (isAdmin) {
            // Fetch all students for Admin
            APIkit.get('admin/students').then(res => {
                if (res.data) {
                    const studentList = Array.isArray(res.data) ? res.data : (res.data.students || []);
                    setStudents(studentList.map(s => ({
                        id: s.id || s._id,
                        name: s.name,
                        roll: s.admissionNo || s.rollNo,
                        image: s.image,
                        status: s.feesStatus || 'PAID',
                        section: s.section || 'A',
                        class: s.class || '10TH'
                    })));
                }
                setIsLoading(false);
            }).catch(() => setIsLoading(false));
        } else {
            // Existing teacher logic
            dispatch(getClassRegistry(user?.class || '10TH', user?.section || 'A', (data) => {
                if (data) {
                    setStudents(data.map(s => ({
                        id: s.id || s._id,
                        name: s.name,
                        roll: s.admissionNo || s.rollNo,
                        image: s.image,
                        status: s.feesStatus || 'PAID',
                        section: s.section || 'A',
                        class: s.class || '10TH'
                    })));
                }
                setIsLoading(false);
            }));
        }
    }, [user?.class, user?.section, isAdmin]);

    const filteredStudents = students.filter(s =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.roll.includes(searchQuery)
    );

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: "SCHOLAR DIRECTORY",
                showBack: true,
                paddingBottom: 45,
                children: (
                    <View style={styles.metaBadge}>
                        <Text style={styles.metaBadgeText}>{filteredStudents.length} SCHOLARS REGISTERED • CLASS {user?.class || '10TH'}-{user?.section || 'A'}</Text>
                    </View>
                )
            }}
        >

            {/* 🔍 SEARCH AXIS */}
            <View style={styles.searchSection}>
                <View style={styles.searchBar}>
                    <Search size={20} color={COLORS.secondary} />
                    <TextInput
                        placeholder="SEARCH SCHOLAR BY NAME OR ADM#"
                        placeholderTextColor={COLORS.secondary + '80'}
                        style={styles.searchInput}
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                </View>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                {/* 📝 SCHOLAR LIST */}
                <View style={styles.listHeader}>
                    <Text style={styles.listTitle}>FLEET REGISTRY</Text>
                    <Text style={styles.countText}>{filteredStudents.length} ACTIVE SCHOLARS</Text>
                </View>

                {isLoading ? (
                    [1, 2, 3, 4, 5].map((i) => (
                        <View key={i} style={[styles.studentCard, { padding: 16 }]}>
                            <View style={styles.cardHeader}>
                                <Skeleton width={50} height={50} borderRadius={25} style={{ marginRight: 16 }} />
                                <View style={{ flex: 1 }}>
                                    <Skeleton width="60%" height={16} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="40%" height={12} borderRadius={4} />
                                </View>
                            </View>
                        </View>
                    ))
                ) : (
                    filteredStudents.map((s) => (
                        <View key={s.id} style={styles.studentCard}>
                            <View style={styles.cardHeader}>
                                <Image source={{ uri: s.image }} style={styles.avatar} />
                                <View style={styles.info}>
                                    <Text style={styles.name}>{s.name}</Text>
                                    <View style={styles.meta}>
                                        <Text style={styles.roll}>{s.roll}</Text>
                                        <View style={styles.dot} />
                                        <Text style={styles.className}>{s.class} - {s.section}</Text>
                                    </View>
                                </View>
                                <View style={[styles.statusBadge, { backgroundColor: s.status === 'PAID' ? '#F0FDF4' : '#FEF2F2' }]}>
                                    <Text style={[styles.statusText, { color: s.status === 'PAID' ? '#15803D' : '#B91C1C' }]}>{s.status}</Text>
                                </View>
                            </View>

                            <View style={styles.cardFooter}>
                                <TouchableOpacity
                                    style={styles.footerAction}
                                    onPress={() => navigation.navigate('AddMarks', { test: { name: 'ACADEMIC PROFILE', subject: 'Aggregated', max: '100' } })}
                                >
                                    <GraduationCap size={16} color={COLORS.secondary} />
                                    <Text style={styles.actionText}>ACADEMIC LOG</Text>
                                </TouchableOpacity>
                                <View style={styles.divider} />
                                <TouchableOpacity style={styles.footerAction}>
                                    <Edit3 size={16} color={COLORS.primary} />
                                    <Text style={[styles.actionText, { color: COLORS.primary }]}>EDIT BIO</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    ))
                )}
                <View style={{ height: 100 }} />
            </ScrollView>

            {/* 🚀 INITIATE PROVISIONING */}
            <View style={styles.actionFooter}>
                <TouchableOpacity style={styles.mainButton}>
                    <Text style={styles.mainButtonText}>ENROLL NEW SCHOLAR</Text>
                    <Plus size={18} color={COLORS.white} />
                </TouchableOpacity>
            </View>
        </Wrapper>
    );
};

export default StudentRegistry;
