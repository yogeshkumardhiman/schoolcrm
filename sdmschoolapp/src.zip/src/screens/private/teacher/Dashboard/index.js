import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { ClipboardList, FileCheck, BookOpen, Bell, Users, User, CalendarDays, LayoutGrid, Clock, MessageCircle } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useSelector } from 'react-redux';
import { useFocusEffect } from '@react-navigation/native';
import { COLORS, APIkit, API_END_POINTS } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';

import Skeleton from '../../../../components/common/Skeleton';

const TeacherDashboard = ({ navigation }) => {
    const insets = useSafeAreaInsets();
    const { user, role } = useSelector(state => state.auth);
    const isAdmin = role?.toLowerCase() === 'admin';
    const [fetching, setFetching] = React.useState(true);
    const [stats, setStats] = React.useState({ 
        attendance: '0%', 
        presentCount: 0,
        totalStudents: 0,
        students: '0', 
        pendingHw: '0', 
        activeTests: 'None' 
    });

    const fetchDashboardTelemetry = React.useCallback(async () => {
        setFetching(true);
        try {
            if (isAdmin) {
                const res = await APIkit.get('admin/students');
                const attRes = await APIkit.get('admin/attendance-summary');
                setStats(prev => ({ 
                    ...prev, 
                    students: res.data.length.toString(), 
                    attendance: `${attRes.data.percentage}%` || '0%' 
                }));
            } else {
                const className = user?.class || '10A';
                // Fetch Students count
                const res = await APIkit.get(`${API_END_POINTS.teacherStudents}/${className}`);
                
                // Fetch Attendance Stats
                const attRes = await APIkit.get(`teacher/attendance-summary/${className}`);
                
                setStats({
                    attendance: `${attRes.data.percentage}%`,
                    presentCount: attRes.data.presentCount,
                    totalStudents: attRes.data.totalStudents,
                    students: attRes.data.totalStudents.toString(),
                    pendingHw: '0',
                    activeTests: 'None'
                });
            }
        } catch (e) {
            console.log("⚓ Faculty Telemetry Fetch Failure:", e);
        } finally {
            setFetching(false);
        }
    }, [user?.class, isAdmin]);

    useFocusEffect(
        React.useCallback(() => {
            fetchDashboardTelemetry();
        }, [fetchDashboardTelemetry])
    );

    const teacherInfo = {
        name: (user?.name || user?.email || 'ADMIN').toUpperCase(),
        class: isAdmin ? 'SCHOOL WIDE' : 'Class ' + (user?.class || '10A'),
        stats: stats
    };

    const menuItems = [
        { 
            title: 'EVENTS', 
            icon: CalendarDays, 
            color: '#F59E0B', 
            route: 'Events', 
            desc: isAdmin ? 'Manage Academy' : 'School Calendar' 
        },
        { 
            title: 'EXAM MARKS', 
            icon: FileCheck, 
            color: '#10B981', 
            route: 'TestList', 
            desc: isAdmin ? 'Global Registry' : 'Score Registry' 
        },
        { 
            title: 'HOMEWORK', 
            icon: BookOpen, 
            color: '#8B5CF6', 
            route: 'AddHomework', 
            desc: isAdmin ? 'School Tasks' : 'Assignments' 
        },
        { 
            title: 'NOTICES', 
            icon: Bell, 
            color: '#EF4444', 
            route: 'AddNotice', 
            desc: isAdmin ? 'Global Alerts' : 'Class Alerts' 
        },
    ];

    return (
        <Wrapper showHeader={false} noTopInset={true} noBottomPadding={true}>
            <View style={[styles.header, { paddingTop: insets.top + 20, backgroundColor: isAdmin ? '#0F172A' : COLORS.primary }]}>
                <View style={styles.headerContent}>
                    <View style={styles.headerInfo}>
                        <Text style={styles.hubTitle}>{isAdmin ? STRINGS.adminControlPanel : STRINGS.institutionalHub}</Text>
                        <Text style={styles.teacherWelcome}>{teacherInfo.name} <Text style={styles.classText}>{teacherInfo.class}</Text></Text>
                    </View>
                    <TouchableOpacity 
                        style={styles.profileBox}
                        onPress={() => navigation.navigate('ProfileScreen')}
                    >
                        <User size={24} color={isAdmin ? '#3B82F6' : COLORS.primary} />
                    </TouchableOpacity>
                </View>
                <View style={[styles.sessionBadge, { backgroundColor: isAdmin ? '#1E293B' : 'rgba(255,255,255,0.1)' }]}>
                    <Clock size={12} color={COLORS.white} />
                    <Text style={styles.sessionText}>{new Date().toLocaleDateString('en-GB')} | {STRINGS.masterAccess}</Text>
                </View>
            </View>

            <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.scrollContent}
            >
                <View style={styles.statsContainer}>
                    <View style={styles.statsRow}>
                        {fetching ? (
                            <>
                                <View style={styles.statCard}>
                                    <Skeleton width="60%" height={12} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="40%" height={24} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="80%" height={10} borderRadius={4} />
                                </View>
                                <View style={styles.statCard}>
                                    <Skeleton width="60%" height={12} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="40%" height={24} borderRadius={4} style={{ marginBottom: 8 }} />
                                    <Skeleton width="80%" height={10} borderRadius={4} />
                                </View>
                            </>
                        ) : (
                            <>
                                <View style={styles.statCard}>
                                    <Text style={styles.statLabel}>{isAdmin ? STRINGS.schoolAttendance : STRINGS.classAttendance}</Text>
                                    <Text style={[styles.statValue, { color: COLORS.green }]}>{stats.attendance}</Text>
                                    <Text style={styles.statDesc}>
                                        {isAdmin ? STRINGS.institutionWide : `${stats.presentCount} / ${stats.totalStudents} ${STRINGS.presentToday}`}
                                    </Text>
                                </View>
                                <View style={styles.statCard}>
                                    <Text style={styles.statLabel}>{isAdmin ? STRINGS.totalScholars : STRINGS.fleetSize}</Text>
                                    <Text style={[styles.statValue, { color: COLORS.secondary }]}>{teacherInfo.stats.students}</Text>
                                    <Text style={styles.statDesc}>{isAdmin ? STRINGS.institutionRegistry : STRINGS.activeScholars}</Text>
                                </View>
                            </>
                        )}
                    </View>
                </View>

                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>{isAdmin ? STRINGS.adminModules : STRINGS.missionControl}</Text>
                </View>

                <View style={styles.gridContainer}>
                    {menuItems.map((item, index) => (
                        <TouchableOpacity
                            key={index}
                            style={styles.gridCard}
                            onPress={() => navigation.navigate(item.route)}
                        >
                            <View style={[styles.iconBox, { backgroundColor: item.color + '10' }]}>
                                <item.icon size={28} color={item.color} strokeWidth={2.5} />
                            </View>
                            <Text style={styles.cardTitle}>{item.title}</Text>
                            <Text style={styles.cardDesc}>{item.desc}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <TouchableOpacity
                    style={[styles.provisionCard, { marginBottom: 15, borderColor: COLORS.primary + '30', backgroundColor: COLORS.primary + '03' }]}
                    onPress={() => navigation.navigate('StudentQueries')}
                >
                    <View style={[styles.provisionLeft, { backgroundColor: COLORS.primary }]}>
                        <MessageCircle size={24} color={COLORS.white} />
                    </View>
                    <View style={styles.provisionInfo}>
                        <Text style={[styles.provisionTitle, { color: COLORS.primary }]}>{STRINGS.scholarQueries.toUpperCase()}</Text>
                        <Text style={styles.provisionDesc}>{STRINGS.queryDesc}</Text>
                    </View>
                    <View style={styles.arrowBox}>
                        <Text style={[styles.arrowText, { color: COLORS.primary }]}>→</Text>
                    </View>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.provisionCard, isAdmin && { backgroundColor: '#1E293B' }]}
                    onPress={() => navigation.navigate('StudentRegistry')}
                >
                    <View style={[styles.provisionLeft, isAdmin && { backgroundColor: '#3B82F6' }]}>
                        <Users size={24} color={COLORS.white} />
                    </View>
                    <View style={styles.provisionInfo}>
                        <Text style={styles.provisionTitle}>{isAdmin ? STRINGS.masterScholarDirectory : STRINGS.scholarDirectory}</Text>
                        <Text style={styles.provisionDesc}>{isAdmin ? STRINGS.institutionRegistry : `Manage ${teacherInfo.class} Profiles`}</Text>
                    </View>
                    <View style={styles.arrowBox}>
                        <Text style={styles.arrowText}>→</Text>
                    </View>
                </TouchableOpacity>

                <View style={{ height: 100 }} />
            </ScrollView>
        </Wrapper>
    );
};

export default TeacherDashboard;
