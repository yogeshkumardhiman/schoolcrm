import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, TextInput, Modal } from 'react-native';
import { Save, Search, CheckCircle2, UserCheck, UserX, Users, Calendar as CalendarIcon, X, Layers, ClipboardList, Bell } from 'lucide-react-native';
import { useSelector } from 'react-redux';
import { useFocusEffect } from '@react-navigation/native';
import { Calendar } from 'react-native-calendars';
import { COLORS, APIkit, API_END_POINTS, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import { CustomButton } from '../../../../components/CustomButton';
import { StatusModal } from '../../../../components/common/StatusModal';


const AttendanceMarking = ({ navigation }) => {
    const { user } = useSelector(state => state.auth);
    const [selectedClass] = useState(user?.class);
    const [selectedSection] = useState(user?.section);
    const [searchQuery, setSearchQuery] = useState('');
    const [isCalendarVisible, setIsCalendarVisible] = useState(false);
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [isLoading, setIsLoading] = useState(false);
    const [students, setStudents] = useState([]);
    const [isCommitting, setIsCommitting] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, type: 'success', title: '', message: '' });

    const showStatus = (type, message, title = '') => {
        setStatusModal({ visible: true, type, message, title });
    };

    useFocusEffect(
        React.useCallback(() => {
            setSelectedDate(new Date().toISOString().split('T')[0]);
        }, [])
    );

    React.useEffect(() => {
        const fetchRegistry = async () => {
            setIsLoading(true);
            try {
                const res = await APIkit.get(`${API_END_POINTS.teacherStudents}/${selectedClass}/${selectedSection}`);
                let formatted = res.data.map(s => ({
                    id: s.id || s._id,
                    name: s.name,
                    roll: s.rollNo || s.admissionNo,
                    status: null,
                    image: s.image || 'https://images.unsplash.com/photo-1544717297-fa95b3ee9bc6?w=200'
                }));

                // Fetch Existing Attendance for this specific date
                try {
                    const attRes = await APIkit.get(`teacher/attendance/${selectedClass}/${selectedDate}`);
                    if (attRes.data && attRes.data.length > 0) {
                        formatted = formatted.map(student => {
                            const record = attRes.data.find(r => r.studentId === student.id);
                            if (record) {
                                const statusMap = { 'PRESENT': 'P', 'ABSENT': 'A', 'LEAVE': 'L' };
                                return { ...student, status: statusMap[record.status] || null };
                            }
                            return student;
                        });
                    }
                } catch (attErr) {
                    console.log("⚓ Historical Logs Retrieval Failure:", attErr);
                }

                setStudents(formatted);
            } catch (e) {
                console.log("⚓ Scholar Registry Fetch Failure:", e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchRegistry();
    }, [selectedClass, selectedDate]);

    const handleCommit = async () => {
        const remaining = students.filter(s => s.status === null).length;
        if (remaining > 0) {
            showStatus('error', `Incomplete Registry: Please mark attendance for ${remaining} more scholars.`);
            return;
        }

        setIsCommitting(true);
        try {
            const payload = {
                class: selectedClass,
                date: selectedDate,
                attendance: students.map(s => ({
                    studentId: s.id,
                    studentName: s.name,
                    status: s.status === 'P' ? 'PRESENT' : (s.status === 'A' ? 'ABSENT' : 'LEAVE')
                }))
            };
            await APIkit.post(API_END_POINTS.markAttendance, payload);
            showStatus('success', 'Mission Accomplished: Attendance Registry Synchronized!');
        } catch (e) {
            console.log("⚓ Attendance Commitment Failure:", e);
            showStatus('error', 'Synchronization Breach: Failed to commit logs.');
        } finally {
            setIsCommitting(false);
        }
    };

    const setStatus = (id, status) => {
        setStudents(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    };

    const markAllPresent = () => {
        setStudents(prev => prev.map(s => ({ ...s, status: 'P' })));
    };

    const presentCount = students.filter(s => s.status === 'P').length;
    const absentCount = students.filter(s => s.status === 'A').length;
    const leaveCount = students.filter(s => s.status === 'L').length;
    const totalMarked = presentCount + absentCount + leaveCount;
    const attendancePercentage = students.length > 0 ? ((presentCount / students.length) * 100).toFixed(0) : 0;

    const filteredStudents = students.filter(s =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.roll.includes(searchQuery)
    );

    const formatDate = (dateString) => {
        const options = { day: '2-digit', month: 'short', year: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-GB', options).toUpperCase();
    };

    const isSunday = new Date(selectedDate).getDay() === 0;
    const isFutureDate = new Date(selectedDate) > new Date();
    const isDisabled = isSunday || isFutureDate;

    return (
        <Wrapper
            noTopInset={true}
            translucent={true}
            statusBarColor="transparent"
            statusBarStyle="light-content"
            showHeader
            headerProps={{
                title: "PRESENCE HUB",
                showBack: navigation.canGoBack(),
                paddingBottom: 50,
                children: (
                    <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 10 }}>
                        <View style={styles.classInfo}>
                            <Users size={16} color={COLORS.primary} />
                            <Text style={styles.selectedClassText}>{selectedClass} - {selectedSection}</Text>
                        </View>

                        <TouchableOpacity
                            style={styles.datePickerBadge}
                            onPress={() => setIsCalendarVisible(true)}
                        >
                            <CalendarIcon size={16} color={COLORS.white} />
                            <Text style={styles.dateBadgeText}>{formatDate(selectedDate)}</Text>
                        </TouchableOpacity>
                    </View>
                )
            }}
            parentStyle={{ backgroundColor: COLORS.background }}
        >
            <View style={{ flex: 1 }}>
                {/* 📊 REAL-TIME TELEMETRY AXIS */}
                <View style={styles.telemetryAxis}>
                    <View style={styles.telemetryBox}>
                        <View style={[styles.iconContainer, { backgroundColor: COLORS.primary + '15' }]}>
                            <Layers size={18} color={COLORS.primary} />
                        </View>
                        <Text style={[styles.telemetryValue, { color: COLORS.primary }]}>{attendancePercentage}%</Text>
                        <Text style={styles.telemetryLabel}>RATIO</Text>
                    </View>

                    <View style={styles.telemetryBox}>
                        <View style={[styles.iconContainer, { backgroundColor: COLORS.green + '15' }]}>
                            <UserCheck size={18} color={COLORS.green} />
                        </View>
                        <Text style={[styles.telemetryValue, { color: COLORS.green }]}>{presentCount}</Text>
                        <Text style={styles.telemetryLabel}>PRES</Text>
                    </View>

                    <View style={styles.telemetryBox}>
                        <View style={[styles.iconContainer, { backgroundColor: (COLORS.orange || '#F59E0B') + '20' }]}>
                            <ClipboardList size={18} color={COLORS.orange || '#F59E0B'} />
                        </View>
                        <Text style={[styles.telemetryValue, { color: COLORS.orange || '#F59E0B' }]}>{leaveCount}</Text>
                        <Text style={styles.telemetryLabel}>LEAVE</Text>
                    </View>

                    <View style={styles.telemetryBox}>
                        <View style={[styles.iconContainer, { backgroundColor: COLORS.red + '15' }]}>
                            <UserX size={18} color={COLORS.red} />
                        </View>
                        <Text style={[styles.telemetryValue, { color: COLORS.red }]}>{absentCount}</Text>
                        <Text style={styles.telemetryLabel}>ABST</Text>
                    </View>
                </View>

                {/* 🗓️ TEMPORAL GOVERNANCE BANNER */}
                {isDisabled && (
                    <View style={{ backgroundColor: COLORS.orange + '10', padding: 12, marginHorizontal: 20, borderRadius: 16, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 15, borderWidth: 1, borderColor: COLORS.orange + '30' }}>
                        <Bell size={18} color={COLORS.orange} />
                        <Text style={{ fontSize: 11, fontFamily: fontFamily.Poppins.Black, color: COLORS.orange, letterSpacing: 0.5, flex: 1 }}>
                            {isSunday
                                ? "SUNDAY | INSTITUTIONAL HOLIDAY - REGISTRY LOCKED"
                                : "TEMPORAL RESTRICTION | CANNOT MARK ATTENDANCE FOR FUTURE DATES"}
                        </Text>
                    </View>
                )}

                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                    {/* 🔍 SEARCH & BULK ACTIONS */}
                    <View style={styles.actionRow}>
                        <View style={styles.searchBox}>
                            <Search size={20} color={COLORS.gray} />
                            <TextInput
                                placeholder="Find Scholar..."
                                style={styles.searchInput}
                                placeholderTextColor={COLORS.gray + '80'}
                                value={searchQuery}
                                onChangeText={setSearchQuery}
                            />
                        </View>
                        <CustomButton
                            title="ALL P"
                            variant="pill"
                            style={{ width: 100, borderRadius: 16, height: 52 }}
                            icon={CheckCircle2}
                            onPress={markAllPresent}
                            disabled={isDisabled}
                        />
                    </View>

                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>ACTIVE SCHOLARS</Text>
                        <View style={styles.badge}>
                            <Text style={styles.badgeText}>{totalMarked}/{students.length}</Text>
                        </View>
                    </View>
                    {filteredStudents.map((student) => (
                        <View key={student.id} style={styles.studentCard}>
                            <View style={styles.cardMain}>
                                <Image source={{ uri: student.image }} style={styles.studentAvatar} />
                                <View style={styles.studentInfo}>
                                    <Text style={styles.studentName}>{student.name}</Text>
                                    <Text style={styles.studentRoll}>{student.roll}</Text>
                                </View>
                            </View>

                            <View style={styles.toggleGroup}>
                                <TouchableOpacity
                                    onPress={() => setStatus(student.id, 'P')}
                                    disabled={isDisabled}
                                    style={[styles.paPill, student.status === 'P' && { backgroundColor: COLORS.green, borderWidth: 1.5, borderColor: COLORS.green }, isDisabled && { opacity: 0.5 }]}
                                >
                                    <Text style={[styles.paText, student.status === 'P' && styles.activeText]}>P</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    onPress={() => setStatus(student.id, 'L')}
                                    disabled={isDisabled}
                                    style={[styles.paPill, student.status === 'L' && { backgroundColor: COLORS.orange || '#F59E0B', borderWidth: 1.5, borderColor: COLORS.orange || '#F59E0B' }, isDisabled && { opacity: 0.5 }]}
                                >
                                    <Text style={[styles.paText, student.status === 'L' && styles.activeText]}>L</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    onPress={() => setStatus(student.id, 'A')}
                                    disabled={isDisabled}
                                    style={[styles.paPill, student.status === 'A' && { backgroundColor: COLORS.red, borderWidth: 1.5, borderColor: COLORS.red }, isDisabled && { opacity: 0.5 }]}
                                >
                                    <Text style={[styles.paText, student.status === 'A' && styles.activeText]}>A</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    ))}

                    <View style={{ height: 120 }} />
                </ScrollView>

                {/* 🚀 MISSION COMMITMENT ACTION */}
                <View style={styles.footer}>
                    <CustomButton
                        title={isDisabled ? "REGISTRY LOCKED" : (totalMarked === students.length ? "COMMIT ATTENDANCE LOG" : `MARK ${students.length - totalMarked} MORE`)}
                        variant="commit"
                        icon={Save}
                        onPress={handleCommit}
                        loading={isCommitting}
                        disabled={students.length === 0 || isCommitting || isDisabled}
                    />
                </View>

                {/* 🗓️ CALENDAR MODAL SECTOR */}
                <Modal
                    visible={isCalendarVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsCalendarVisible(false)}
                >
                    <TouchableOpacity
                        style={styles.modalContainer}
                        activeOpacity={1}
                        onPress={() => setIsCalendarVisible(false)}
                    >
                        <View style={styles.modalContent}>
                            <View style={styles.modalHeader}>
                                <Text style={styles.modalTitle}>SELECT LOG DATE</Text>
                                <TouchableOpacity onPress={() => setIsCalendarVisible(false)}>
                                    <X size={24} color={COLORS.secondary} />
                                </TouchableOpacity>
                            </View>

                            <View style={styles.calendarWrapper}>
                                <Calendar
                                    current={selectedDate}
                                    onDayPress={(day) => {
                                        setSelectedDate(day.dateString);
                                        setIsCalendarVisible(false);
                                    }}
                                    markedDates={{
                                        [selectedDate]: { selected: true, selectedColor: COLORS.primary }
                                    }}
                                    theme={{
                                        selectedDayBackgroundColor: COLORS.primary,
                                        todayTextColor: COLORS.primary,
                                        arrowColor: COLORS.primary,
                                        textDayHeaderFontFamily: fontFamily.Poppins.Black,
                                        textDayFontFamily: fontFamily.Poppins.SemiBold,
                                        textMonthFontFamily: fontFamily.Poppins.Black,
                                    }}
                                />
                            </View>
                        </View>
                    </TouchableOpacity>
                </Modal>
            <StatusModal
                visible={statusModal.visible}
                type={statusModal.type}
                title={statusModal.title}
                message={statusModal.message}
                okTitle={statusModal.type === 'success' ? "DISMISS HUB" : "RETRY MISSION"}
                onClose={() => {
                    setStatusModal({ ...statusModal, visible: false });
                    if (statusModal.type === 'success') {
                        navigation.goBack();
                    }
                }}
            />
        </View>
        </Wrapper>
    );
};

export default AttendanceMarking;
