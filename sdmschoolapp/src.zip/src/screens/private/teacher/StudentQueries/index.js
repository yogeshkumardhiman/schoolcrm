import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Modal, TextInput, ActivityIndicator, RefreshControl } from 'react-native';
import { CheckCircle, Clock, Send, X, User, Edit3 } from 'lucide-react-native';
import { useSelector } from 'react-redux';
import { COLORS, APIkit, STRINGS, fontFamily } from '../../../../utils';
import { styles } from './styles';
import { Wrapper } from '../../../../components/Wrapper';
import Skeleton from '../../../../components/common/Skeleton';
import { StatusModal } from '../../../../components/common/StatusModal';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const StudentQueries = () => {
    const { user } = useSelector(state => state.auth);
    const [queries, setQueries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    
    const [selectedQuery, setSelectedQuery] = useState(null);
    const [replyText, setReplyText] = useState('');
    const [submitting, setSubmitting] = useState(false);
    const [statusModal, setStatusModal] = useState({ visible: false, type: 'success', title: '', message: '' });

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);
        fetchQueries().then(() => setRefreshing(false));
    }, []);

    useEffect(() => {
        fetchQueries();
    }, []);

    const fetchQueries = async () => {
        try {
            // Endpoints: /api/teacher/grievance/:className/:section
            const res = await APIkit.get(`teacher/grievance/${user.class}/${user.section || 'A'}`);
            setQueries(res.data);
        } catch (e) {
            console.log("Fetch Teacher Queries Error:", e);
        } finally {
            setLoading(false);
        }
    };

    const handleReply = async () => {
        if (!replyText.trim()) return;
        setSubmitting(true);
        await sleep(1000); // Visual commitment delay
        try {
            const res = await APIkit.put(`teacher/grievance/reply/${selectedQuery.id || selectedQuery._id}`, {
                teacherReply: replyText,
                responderName: user.name
            });
            if (res.data) {
                setQueries(queries.map(q => 
                    (q.id === selectedQuery.id || q._id === selectedQuery._id) 
                    ? { ...q, teacherReply: replyText, status: 'RESOLVED' } 
                    : q
                ));
                setSelectedQuery(null);
                setReplyText('');
                setStatusModal({ 
                    visible: true, 
                    type: 'success', 
                    title: 'RESPONSE COMMITTED', 
                    message: "The scholar has been notified of your resolution." 
                });
            }
        } catch (e) {
            console.log("Reply Error:", e);
            setStatusModal({ 
                visible: true, 
                type: 'error', 
                title: 'COMMITMENT FAILED', 
                message: e.message || "Failed to commit resolution to institutional vault." 
            });
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Wrapper noTopInset={true} translucent={true} showHeader headerProps={{ title: STRINGS.scholarQueries.toUpperCase(), showBack: true }}>
            <ScrollView 
                showsVerticalScrollIndicator={false} 
                contentContainerStyle={styles.scrollContent}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
            >
                {loading ? (
                    [1, 2, 3, 4].map(i => (
                        <View key={i} style={styles.queryCard}>
                            <Skeleton width={150} height={20} borderRadius={4} style={{ marginBottom: 12 }} />
                            <Skeleton width="100%" height={60} borderRadius={12} />
                        </View>
                    ))
                ) : queries.length === 0 ? (
                    <View style={{ alignItems: 'center', marginTop: 150 }}>
                        <Clock size={64} color="#CBD5E1" />
                        <Text style={{ marginTop: 20, color: '#94A3B8', fontFamily: fontFamily.Poppins.ExtraBold }}>{STRINGS.allClear}</Text>
                        <Text style={{ color: '#94A3B8', fontSize: 12 }}>{STRINGS.noPendingQueries}</Text>
                    </View>
                ) : (
                    queries.map(item => (
                        <View key={item.id || item._id} style={styles.queryCard}>
                            <View style={styles.cardHeader}>
                                <View style={styles.studentInfo}>
                                    <Text style={styles.studentName}>{item.studentName?.toUpperCase()}</Text>
                                    <Text style={styles.studentClass}>ROLL: {item.studentId || 'N/A'}</Text>
                                </View>
                                <View style={styles.subjectBadge}>
                                    <Text style={styles.subjectText}>{item.subject?.toUpperCase()}</Text>
                                </View>
                            </View>

                            <View style={styles.messageBox}>
                                <Text style={styles.messageText}>{item.message}</Text>
                            </View>

                             {item.status === 'RESOLVED' ? (
                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                    <View style={styles.replyPreview}>
                                        <CheckCircle size={16} color="#10B981" />
                                        <Text style={styles.resolvedText}>{STRINGS.resolved}</Text>
                                    </View>
                                    <TouchableOpacity 
                                        onPress={() => {
                                            setSelectedQuery(item);
                                            setReplyText(item.teacherReply || '');
                                        }}
                                        style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EFF6FF', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8 }}
                                    >
                                        <Edit3 size={12} color="#2563EB" />
                                        <Text style={{ color: '#2563EB', fontSize: 10, fontFamily: fontFamily.Poppins.Bold }}>{STRINGS.editResponse}</Text>
                                    </TouchableOpacity>
                                </View>
                            ) : (
                                <TouchableOpacity 
                                    style={styles.replyBtn} 
                                    onPress={() => {
                                        setSelectedQuery(item);
                                        setReplyText('');
                                    }}
                                >
                                    <Text style={styles.replyBtnText}>{STRINGS.respondNow}</Text>
                                </TouchableOpacity>
                            )}
                        </View>
                    ))
                )}
                <View style={{ height: 100 }} />
            </ScrollView>

            {/* REPLY MODAL */}
            <Modal visible={!!selectedQuery} transparent animationType="fade">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
                            <Text style={styles.modalTitle}>{STRINGS.respondTo} {selectedQuery?.studentName?.toUpperCase()}</Text>
                            <TouchableOpacity onPress={() => setSelectedQuery(null)}>
                                <X size={24} color={COLORS.secondary} />
                            </TouchableOpacity>
                        </View>
                        <Text style={styles.originalMsg}>Q: "{selectedQuery?.message}"</Text>

                        <TextInput
                            style={styles.input}
                            placeholder={STRINGS.typeResponse}
                            multiline
                            value={replyText}
                            onChangeText={setReplyText}
                        />

                        <TouchableOpacity 
                            style={[styles.submitBtn, (!replyText.trim() || submitting) && { opacity: 0.5 }]} 
                            onPress={handleReply}
                            disabled={submitting || !replyText.trim()}
                        >
                            {submitting ? (
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                    <ActivityIndicator size="large" color={COLORS.white} style={{ marginRight: 12 }} />
                                    <Text style={styles.submitText}>{STRINGS.saving}</Text>
                                </View>
                            ) : (
                                <Text style={styles.text}>{STRINGS.submitResponse}</Text>
                            )}
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.cancelBtn} onPress={() => setSelectedQuery(null)}>
                            <Text style={styles.cancelText}>{STRINGS.cancelEdit}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            <StatusModal
                visible={statusModal.visible}
                type={statusModal.type}
                title={statusModal.title}
                message={statusModal.message}
                onClose={() => setStatusModal({ ...statusModal, visible: false })}
            />
        </Wrapper>
    );
};

export default StudentQueries;
