import { StyleSheet } from 'react-native';
import { COLORS,fontFamily} from '../../../../utils';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8FAFC',
    },
    scrollContent: {
        padding: 20,
    },
    queryCard: {
        backgroundColor: COLORS.white,
        borderRadius: 20,
        padding: 20,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: '#F1F5F9',
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        marginBottom: 12,
    },
    studentInfo: {
        flex: 1,
    },
    studentName: {
        fontSize: 16,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.secondary,
    },
    studentClass: {
        fontSize: 12,
        color: '#64748B',
        fontFamily: fontFamily.Poppins.SemiBold,
    },
    subjectBadge: {
        backgroundColor: COLORS.primary + '10',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 6,
    },
    subjectText: {
        fontSize: 10,
        fontFamily: fontFamily.Poppins.ExtraBold,
        color: COLORS.primary,
    },
    messageBox: {
        backgroundColor: '#F8FAFC',
        padding: 12,
        borderRadius: 12,
        marginBottom: 15,
    },
    messageText: {
        fontSize: 14,
        color: '#475569',
        fontFamily: fontFamily.Poppins.Regular,
        lineHeight: 20,
    },
    replyPreview: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
        borderTopWidth: 1,
        borderTopColor: '#F1F5F9',
    },
    resolvedText: {
        fontSize: 12,
        fontFamily: fontFamily.Poppins.ExtraBold,
        color: '#10B981',
        marginLeft: 6,
    },
    pendingText: {
        fontSize: 12,
        fontFamily: fontFamily.Poppins.ExtraBold,
        color: '#F59E0B',
        marginLeft: 6,
    },
    replyBtn: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 10,
        alignSelf: 'flex-start',
    },
    replyBtnText: {
        color: COLORS.white,
        fontSize: 12,
        fontFamily: fontFamily.Poppins.ExtraBold,
    },
    // Modal Styles
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(15, 23, 42, 0.6)',
        justifyContent: 'center',
        padding: 20,
    },
    modalContent: {
        backgroundColor: COLORS.white,
        borderRadius: 24,
        padding: 24,
    },
    modalTitle: {
        fontSize: 20,
        fontFamily: fontFamily.Poppins.Black,
        color: COLORS.secondary,
        marginBottom: 10,
    },
    originalMsg: {
        fontSize: 12,
        color: '#64748B',
        fontFamily: fontFamily.Poppins.Medium,
        fontStyle: 'italic',
        marginBottom: 20,
    },
    input: {
        backgroundColor: '#F8FAFC',
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        minHeight: 120,
        textAlignVertical: 'top',
        color: COLORS.secondary,
        fontSize: 14,
        fontFamily: fontFamily.Poppins.Regular,
    },
    submitBtn: {
        backgroundColor: COLORS.primary,
        height: 56,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
    },
    submitText: {
        color: COLORS.white,
        fontFamily: fontFamily.Poppins.Black,
        fontSize: 16,
    },
    cancelBtn: {
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 10,
    },
    cancelText: {
        color: '#64748B',
        fontFamily: fontFamily.Poppins.Bold,
    }
});
