// Backend server endpoints for SDM School App
const WEB_BASE_URL = "http://192.168.1.44:5001/";
const WEB_BASE_URL_PROFILE = "http://192.168.1.44:5001/";
const API_BASE_URL = "http://192.168.1.44:5001/api/";
// Note: Using 192.168.1.44 (Your computer's verified local IP)
// Ensure real device is on the SAME Wi-Fi network.

const API_END_POINTS = {
    // Auth Endpoints
    login: "auth/login",

    // Admin Endpoints
    students: "admin/students",
    staff: "admin/staff",
    exams: "admin/exams",
    gallery: "admin/gallery",
    attendance: "admin/attendance",
    schoolInfo: "school-info",
    notices: "notices",
    homework: "homework",
    events: "events",
    studentDashboard: "student/dashboard",
    studentAttendance: "student/attendance",
    studentResults: "student/results",
    // Teacher Endpoints
    teacherStudents: "teacher/students",
    markAttendance: "teacher/attendance/mark",
    bulkResults: "teacher/results/bulk",
    broadcast: "teacher/broadcast",
    stats: "stats",
    homeworkStatus: "student/homework/status",
    myHomeworkStatus: "student/homework/my-status"
}

export {
    API_BASE_URL,
    API_END_POINTS,
    WEB_BASE_URL,
    WEB_BASE_URL_PROFILE
}