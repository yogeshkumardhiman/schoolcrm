const COLORS = {
  primary: "#6366F1", // Figma Indigo
  secondary: "#1F2937",
  accent: "#A855F7", // Figma Purple
  success: "#22C55E",
  green: "#22C55E",
  warning: "#F59E0B",
  danger: "#EF4444",
  red: "#EF4444",
  purple: "#8B5CF6",
  white: "#FFFFFF",
  black: "#000000",
  gray: "#94A3B8",
  background: "#F8FAFC",
  border: "#E2E8F0",
  orange: "#F59E0B",
  gradient: ["#6366F1", "#A855F7"], // Figma Dynamic Gradient
};

export {
  COLORS
};
