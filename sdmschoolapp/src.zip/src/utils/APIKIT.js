import axios from "axios";
import { API_BASE_URL } from "./consts/Api";
import { CACHE } from "./helper";
import { CACHE_PARAMS } from "./consts/Global";
let APIkit = axios.create({
    timeout: 20000,
    baseURL: API_BASE_URL

})
APIkit.interceptors.request.use(async request => {
    const localToken = await CACHE.get(CACHE_PARAMS.accessToken)
    // console.log("localToken====>", localToken);
    if (localToken) {
        request.headers.Authorization = `Bearer ${localToken}`
    }
    // console.log("`Basic ${localToken}`",`Ba ${localToken}`)
    return request;
})
export { APIkit }